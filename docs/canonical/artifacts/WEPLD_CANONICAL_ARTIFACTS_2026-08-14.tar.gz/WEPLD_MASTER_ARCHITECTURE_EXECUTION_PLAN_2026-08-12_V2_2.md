# WePLD — Master Architecture & Execution Plan V2.2

**Report date:** 2026-08-12  
**Classification:** Founder-gated Stage-3 reconciliation — READ-ONLY planning deliverable  
**Repository baseline:** `wepld/wepld@993b2fb55af038091f365ad29d0740bdb1bd6c9e`  
**Operative canonical reference:** `WEPLD_CANONICAL_MASTER_REFERENCE_2026-08-11_V1_5`  
**Stage-1 source:** `C:\tmp\WEPLD_MASTER_ARCHITECTURE_EXECUTION_PLAN_2026-08-12.md`  
**Stage-2 source:** `C:\tmp\WEPLD_MASTER_PLAN_ADVERSARIAL_REVIEW_2026-08-12.md`  
**Implementation authorization created by this document:** **NONE**  
**Repository mutations performed while producing this document:** **NONE**  
**Version identity:** `V2.2` — bounded successor to V2.1; architecture and roadmap unchanged

---

## 0. Read-Me, Integrity, and Evidence Labels

This is the bounded Stage-3 revision of the existing Stage-1 Master Plan. It is not a new discovery pass and does not silently replace Stage 1. The original remains byte-for-byte preserved. V2.2 preserves the V2/V2.1 architecture and roadmap while applying the final bounded pre-ratification text corrections recorded in the companion delta; V2.1 remains immutable predecessor evidence.

### 0.1 Input integrity

| Input | Directly inspected | Size | SHA-256 |
|---|---:|---:|---|
| Stage-1 Master Plan | YES | 296,420 bytes | `74d5440d12f36f63255d30dc9f28296cfe43caf685ca05fd71d00c54f7975bad` |
| Canonical V1.5 at `C:\Users\Shehr\OneDrive\Desktop\wepldorigin\WEPLD_CANONICAL_MASTER_REFERENCE_2026-08-11_V1_5(1).md` | YES — complete through its final state | 242,134 bytes; 4,621 newline-terminated lines | `aba5f2e50e2b0ecf2b18fd07cf46e7eaffdc11fe641aea5ffcb3974abb6eb9cd` |
| Stage-2 Adversarial Review | YES | 92,231 bytes | `67fe5dcfa44fed558b36cf987c0cb53622170244286b8208e29adf888a613512` |
| Code Review / Assurance Acquisition Study V2 | YES — all body paragraphs, 17 tables, headers, and footer structurally inspected | 66,393 bytes | `312af9ae3a2e1620b27e57f12fd783d806b4c07f01f7348309e2e116e938f41d` |
| Immediate predecessor Master Plan V2.1 | YES — complete artifact and bounded correction target | 151,328 bytes | `cd5b444d3149223011ea90e7449c52107814b049655939c2597169350ce9ff63` |
| Original Stage-3 Master Plan V2 | YES — immutable predecessor of V2.1 | canonical LF-normalized | `ca3d3eac77ac53ed7e4989b7d00c9c4d28cc62f2e543af46d4bfbd5b715f5e35` |

The V2 study contained no footnotes, endnotes, comments, or tracked changes. LibreOffice/`soffice` was unavailable, so DOCX page-image rendering could not be performed; structural OOXML inspection covered all text-bearing parts. Stale template metadata in that DOCX is not used as evidence.

### 0.2 Evidence labels

| Label | Meaning |
|---|---|
| `VERIFIED_CURRENT_REPOSITORY_FACT` | Freshly verified live against GitHub and, for refs, independently with `git ls-remote`. |
| `DIRECT_V1_5_EVIDENCE` | Explicitly present in the directly inspected V1.5 artifact. |
| `ACCEPTED_CANONICAL_GOVERNANCE` | Accepted governance on canonical `main`. |
| `FOUNDER_DIRECTION` | Explicit current founder instruction; highest planning authority here. |
| `STAGE2_CORRECTION` | Adversarial correction adopted by the founder for this reconciliation. |
| `V2_STUDY_EVIDENCE` | Supplied acquisition-study evidence; proposals remain proposals unless separately adopted. |
| `IMPLEMENTATION_EVIDENCE` | Existing code/tests/prototypes; not architecture merely by existence. |
| `EXTERNAL_SOURCE_EVIDENCE` | Pinned third-party source/product evidence with its stated verification limits. |
| `PROPOSED_ARCHITECTURE` | V2 technical resolution awaiting founder ratification where identified. |
| `UNRESOLVED_FOUNDER_DECISION` | A historical Stage-3 decision ID in §37; current founder action is grouped into six ratification packages, while `FD-P0-013` remains future evidence-gated. |

Authority precedence is:

```text
current founder instruction
→ freshly verified accepted governance on canonical main
→ directly inspected V1.5
→ explicitly ratified decisions
→ Stage-2 corrections adopted for this pass
→ proposed discovery/acquisition studies
→ implementation donors
→ external systems
```

V1.5 directly establishes ChangeStack and Design/Accessibility Review. It does **not** name every Stage-2 contract correction: `ReviewCoverage`, `ReviewOutcome`, `ReviewProducerRun`, `ReviewSynthesis`, `ReviewTour`, and `S3-D` are attributed to current founder direction and Stage-2/V2 semantics, not falsely presented as V1.5 text.

---

## 1. Executive Verdict

**Executive result:** reconciliation is complete enough for founder ratification, with six current founder ratification packages, ten historical Stage-3 decision IDs retained for traceability, `FD-P0-013` future evidence-gated, and two scoped blockers. The single formal verdict is recorded in §40.

The architecture is coherent after the mandatory corrections. V1.5 has now been directly inspected, so the former missing-evidence blocker, old `BLOCK-002`, and `FD-P0-024` are closed. V1.5 §42.3 directly establishes the ChangeStack/DeliveryGraph contract family, closing old `BLOCK-003` and `FD-P0-003`. V1.5 §§4, 14.1, 19.1, and 42.15 retain Design/Accessibility Review, accessibility, and Arabic/RTL, closing `FD-P0-002`.

V2 makes five structural corrections:

1. **Logical Assurance ownership is separated from physical trust placement.** The Trusted Computing Base contains only authority-bearing validation and persistence. Scanners, compilers, AI reviewers, runtime verifiers, adapters, synthesis, tours, dashboards, and forge comments execute or render outside it.
2. **Ten primary slices remain.** The numbered S3.5 is removed. `S3-D — ASSURANCE SEED GATE` is non-primary and tightly bounded.
3. **The benchmark is scientifically coherent.** It uses `D0/A/B/C/D`, exactly 20 metric families, explicit strata, staged corpora, context ablations, uncertainty controls, and Pareto/non-inferiority criteria rather than universal monotonic improvement.
4. **Contract semantics are corrected.** `ReviewCoverage` is immutable evidence; `ReviewSynthesis` and `ReviewTour` remain projections/artifacts; `ReviewProducerRun` is a non-verdict producer record; `ReviewOutcome != CompletionDecision` is a hard authority invariant.
5. **Source inspection is not admission.** Acquisition is partial and component-specific. MonkeyCode is a reference/benchmark/negative oracle; OpenReview rights remain unknown; reviewdog derivation requires artifact-level rights review.

Two scoped blockers remain:

- `B-GOV-001`: the repository is Public while adopted governance and the proprietary posture say Private. This blocks repository implementation/code publication under the present workflow.
- `B-WIN-001`: Windows hostile-worker containment is unqualified. This blocks untrusted local worker execution, not P0 planning. Trusted deterministic tooling is allowed only under a disclosed qualified profile whose input-trust class is explicit; processing untrusted project content requires qualification for that threat class and is never inferred safe from tool provenance alone.

Ten historical Stage-3 decision IDs remain in §37 for traceability; the current founder-facing ask is the six packages in §37.0, while `FD-P0-013` remains future evidence-gated. They do not authorize implementation. No S1 work begins from this document.

### 1.1 Development method is now binding direction

The following distinction is controlling:

```text
A. EXTERNAL METHODS USED TO BUILD WEPLD NOW
   Spec Kit + Ponytail FULL + Cubic when data-egress policy permits

B. CAPABILITIES WEPLD INTERNALIZES LATER
   S5: typed Spec Kit mechanics + AGILLE + Plan Qualification + Ponytail Sufficiency
   S7+: WePLD Native Review & Assurance benchmarked against Cubic
```

Spec Kit artifacts do not become canonical WePLD authority. Ponytail cannot minimize away security, validation, correctness, recovery, evidence, accessibility, or authority boundaries. Cubic is independent review evidence, not write authority, acceptance, or a `CompletionDecision`.

---

## 2. Verified Canonical Repository State

**Verification window:** 2026-08-12, read-only. GitHub connector results were independently cross-checked for all three live branch refs with `git ls-remote`.

### 2.1 Repository

| Field | Live value |
|---|---|
| Repository | `wepld/wepld` |
| Repository ID | `1298635437` |
| Owner | `wepld` (`304164736`) |
| Visibility | **PUBLIC** |
| Default branch | `main` |
| Live main | `993b2fb55af038091f365ad29d0740bdb1bd6c9e` |
| Archived | false |
| Connected identity | `IamShehri` (`285091250`) |
| Connected permission | `admin=false`, `maintain=false`, `pull=true`, `push=true`, `triage=true` |

`VERIFIED_CURRENT_REPOSITORY_FACT`: Public visibility still conflicts with the proprietary/Private governance posture. This report does not change visibility or governance.

### 2.2 PR #11

| Field | Live value |
|---|---|
| State | OPEN · DRAFT · UNMERGED |
| Mergeability | MERGEABLE · CLEAN |
| Head | `68cab399748c5c103b8f96380da69fdffca4d3fe` |
| Base | live `main@993b2fb55af038091f365ad29d0740bdb1bd6c9e` |
| Commits/files | 1 commit; 10 documentation files; +1,105/−0 |
| Independent reviews/threads | none |
| Comments | none |
| Check | `Architecture docs validation` completed successfully |

It remains evidence and donor material. It must not be merged unchanged. The V2 recommendation is replacement-first, cross-linked closure as superseded, subject to founder authorization (§23).

### 2.3 PR #1

| Field | Live value |
|---|---|
| State | OPEN · DRAFT · UNMERGED |
| Mergeability | NON-MERGEABLE · DIRTY |
| Head | `d5ef318468b6c35df3c14c1c5f72beb1191baf29` |
| Recorded base | `main@f0ef22c823dc2e6d9002bc8b6400bb194529e16d`, not current main |
| Commits/files | 46 commits; 142 files; +20,443/−15 |
| Independent reviews/threads | none |
| Comments | four self-authored remediation comments; no independent approval |
| Check | `CI` completed successfully at the head |

It remains implementation evidence and test/donor material, never a wholesale baseline. V2 recommends freezing exact provenance and a salvage/reject ledger, optionally creating a founder-authorized archive ref if durable reachability requires it, then closing the PR as superseded (§24).

---

## 3. Authority / Evidence Precedence

The operative planning baseline is the direct V1.5 artifact, not V1.4. V1.5 internally contains an earlier roadmap in §26.1 and a later final-discovery roadmap in §42.21. The later §42.21 sequence controls because it incorporates the final sweep and moves Fehrest earlier. Current founder direction then adds the non-primary S3-D gate and the build-method contract.

Deliberate overrides and refinements are recorded rather than hidden:

- V1.5 §23.2 uses an older `A/B/C/D` benchmark. Current direction adds `D0`, defines B as governed ReviewRules, places Fehrest+AGILLE in C, and adds full topology in D.
- V1.5 supplies useful independence dimensions, but Stage 2 refines them into role-relative measurable relationships.
- V1.5 treats Cubic primarily as a product/behavior oracle. Current founder direction additionally requires Cubic as an external reviewer while building WePLD when egress policy permits.
- V1.5 does not name S3-D. S3-D is an adopted Stage-2/current-founder sequencing correction.

No draft PR, external product, worker output, Spec Kit Markdown, Cubic result, benchmark score, or implementation donor can override canonical authority by itself.

---

## 4. Reconciled Product Thesis

WePLD is the Universal Engineering Intelligence System: one governed engineering truth across models, workers, tools, skills, context, evidence, execution, assurance, recovery, and human authority. The durable moat is the engineering system and Project Brain, not a proprietary foundation model.

### 4.1 Falsifiable outcome claim

```text
For the same target, task, model/worker, applicable tool conditions, and budget,
WePLD should produce a measurably better accepted engineering outcome
than the corresponding ungoverned/raw route,
without violating safety guardrails or hiding cost, latency, or human burden.
```

The claim is tested through `D0/A/B/C/D`, context ablations, and operational profiles. No universal metric-by-metric monotonic improvement is assumed. A useful system may trade latency or spend for lower false-success and escaped-defect rates; the trade must meet preregistered floors, budgets, non-inferiority margins, and Pareto criteria.

The founder's Cubic decision adds a second falsifiable comparison:

```text
CUBIC
vs WEPLD_NATIVE
vs CUBIC + WEPLD_NATIVE
```

Target, risk profile, and applicable model/budget conditions are held constant where scientifically appropriate.

### 4.2 What the thesis is not

- It is not “more agents is better.”
- It is not “more context is better.”
- It is not “a clean review means complete.”
- It is not “local means secure.”
- It is not “a public source repository grants reusable rights.”
- It is not “an external development tool becomes product authority.”
- It is not permission to ship every long-term capability in Alpha.

### 4.3 WePLD Development Method Contract

This contract governs any future slice only after that slice receives explicit founder authorization.

**Spec Kit — required external planning workflow.** Use, as appropriate:

```text
constitution → specify → clarify → plan → checklist → analyze → tasks → implement
```

Each artifact has source, digest, scope, supersession, and mapping to WePLD-owned decisions/acceptance obligations. `Spec Kit artifact != WePLD canonical authority`. Product-native mechanics arrive in S5; external use starts now.

**Ponytail — always on, `PONYTAIL_MODE = FULL`.** Every proposal asks:

- Does this need to exist?
- Is it already solved in WePLD?
- Can stdlib, the native platform, an already-admitted dependency, or a qualified reusable component solve it?
- Can a smaller architecture solve it?
- Why this abstraction, dependency, process, privilege, worker, or service?

Ponytail preserves security, validation, correctness, recovery, evidence, accessibility, and authority boundaries. For worker topology, one qualified worker is preferred unless an additional worker has positive marginal accepted-outcome value after coordination cost, latency, duplicated context, independence need, and synthesis overhead.

**Cubic — required independent build reviewer when egress permits.** For code-changing slices:

```text
builder
→ deterministic checks
→ Cubic local/preflight review
→ validate/fix findings
→ deterministic checks
→ Cubic re-review
→ push/open PR (only when separately authorized)
→ Cubic PR review
→ repair
→ Cubic re-review
→ additional independent/adversarial review when risk requires
→ ChatGPT architecture/evidence reconciliation
→ founder acceptance
```

If policy denies source/code egress:

```text
CUBIC_STATUS = NOT_RUN_DATA_EGRESS_DENIED
```

That state is never converted to PASS. If egress would otherwise be permitted but Cubic is unavailable, record `CUBIC_STATUS = NOT_RUN_UNAVAILABLE`; unavailability never becomes success. `Cubic clean != CompletionDecision`; `Cubic approval != founder acceptance`; `Cubic finding != write authority`; `Cubic unavailable != PASS`.

**Development-tool provenance qualification.** Before the first code-changing slice, and whenever a tool or materially relevant configuration changes, the development packet records supply-chain evidence for the external build method:

- **Spec Kit:** exact release/tag/commit where applicable; workflow/template version or digest; configuration; source/provenance.
- **Ponytail:** exact release/version/commit where applicable; ruleset/skill/configuration digest; `PONYTAIL_MODE = FULL`; source/provenance.
- **Cubic:** CLI/client version; review configuration/profile; observable service/policy snapshot where applicable; data-egress classification; retention/disclosure qualification; exact target/revision reviewed.

This evidence qualifies the development method; it grants none of these tools canonical WePLD authority. Any exceptional acceptance without the normally required Cubic review requires an explicit waiver by the same authorized acceptance authority that may decide G9, an independently qualified substitute review route, and a recorded residual limitation. A waiver is not a PASS for the missing Cubic route.

---

## 5. Reconciled Vocabulary and Domain Model

### 5.1 Canonical hierarchy

```text
Tenant / Organization
  └─ Team
      └─ Project
          ├─ Workspace
          └─ Work
              └─ Mission
                  └─ Task
                      └─ Attempt
```

The hierarchy is the working canonical model from V1.5; final aggregate ownership remains founder decision 4. Distinctions remain strict: Team is governance; Work is durable coordination; Mission is executable outcome; Task is execution unit; Attempt is one execution instance. Chat, room, canvas, branch, worktree, sandbox, VM, process, session, provider, model, worker, and harness do not become hidden canonical identity.

### 5.2 Change and review identities

`DIRECT_V1_5_EVIDENCE`: V1.5 §42.3 establishes `ChangeUnit`, `ChangeStack`, `ChangeDependency`, `ChangeStackRevision`, `RestackDecision`, `ChangeConflict`, `StackAssuranceResult`, `StackDeliveryDecision`, and `SpeculativeCheckReuseEvidence`. Exact fields, revisions, and transitions are P0 technical contract work; existence is no longer a founder question.

Review producer execution is named `ReviewProducerRun` by default. `ReviewPassRecord` may be retained only if compatibility evidence requires it and its schema mechanically states that it is not a verdict.

### 5.3 Consistency and persistence classes

| Class | Semantics |
|---|---|
| Authority, policy, approvals, grants, budgets, completion | Strong/causal, versioned, explicit lifecycle |
| Owned aggregates | Optimistic concurrency with revision checks where safe |
| Facts, receipts, findings, decisions, evidence | Append/idempotent, immutable identity/digest |
| `ReviewCoverage` | Immutable append-only execution evidence bound to `ReviewPlan` and producer runs |
| Search, graphs, dashboards, `ReviewSynthesis`, `ReviewTour`, forge comments | Rebuildable projections/content-addressed artifacts |
| Presence | Lease-derived/best effort |

Coverage cannot be regenerated later to make an incomplete old review appear complete. Projection schemas are not prematurely frozen as canonical domain truth.

---

## 6. Canonical Subsystem Ownership Matrix

| Subsystem/domain | Owns | Must not own |
|---|---|---|
| Work | Durable human/team coordination and links | Execution, tool effects, completion authority |
| AGILLE | Rigor, specification/planning gates, acceptance obligations, admissibility | Runtime state or effect authorization |
| Mission Runtime | Mission/Plan/Task/Attempt/Lease, checkpoints, retries, waits, cancellation, effect orchestration, recovery | Membership, policy authorship, canonical knowledge |
| Mirefa | Qualification/catalog/route evidence for models, workers, providers, tools, skills, substrates, components | Authority |
| Edara | Staffing/delegation/topology decision structure and minimum-sufficient team | Grants, runtime truth, acceptance, a separate service in Alpha |
| Nawat | Principal identity, authority, capability grants, revocation, effect-time authorization | Staffing, security scanning, review verdicts |
| AMAN | Security/risk signals, scanner normalization, threats and defensive observations | Effect authorization |
| Fehrest | Project Brain, provenance, branch/temporal truth, context compilation, knowledge admission | Permission or effect authority |
| Byan | Derived metrics, benchmarks, analytical views, outcome learning candidates | Operational/canonical authority |
| Assurance | Logical evaluation ownership, findings, evidence adjudication, coverage, review outcomes | CompletionDecision, mutation authority by finding |
| Trusted Completion | Authorized decision about what counts as complete after evidence/admissibility/authority checks | Reviewer self-certification |

### 6.1 Minimal Assurance TCB

Logical ownership does not imply physical trust placement.

**Inside the Rust Trusted Core only where necessary to enforce truth/authority:**

- contract and schema validation;
- immutable `ReviewTarget` identity validation;
- `AssuranceProfile` and `ReviewPlan` policy validation;
- evidence/digest verification;
- finding admission and state-transition validation;
- immutable `ReviewCoverage` persistence;
- `ReviewOutcome` persistence;
- authority separation, including `ReviewOutcome != CompletionDecision`.

**Outside the TCB:**

- deterministic scanners, linters, compilers, and test tools;
- AI reviewers and their model/provider harnesses;
- runtime-verifier workloads;
- format-specific adapters where practical;
- finding generation and synthesis workers;
- `ReviewTour`, dashboards, and forge comments.

Untrusted producer output enters the Core only through bounded, versioned, hostile-input validation. The TCB may reject or admit evidence; it does not need to contain every producer.

---

## 7. Cross-Subsystem Invariants

1. **Human final authority:** protected acceptance/release remains authorized-human controlled.
2. **UI zero authority:** UI, chat, dashboard, forge, Spec Kit, and Cubic surfaces are projections/inputs, not policy boundaries.
3. **No ambient authority:** every effect uses typed scope, purpose, budget, expiry, revocation, and receipt.
4. **Builder cannot self-certify:** acceptance-critical completion requires independent evidence and authority.
5. **Review is not completion:** `ReviewProducerRun`, finding, coverage, synthesis, tour, verification observation, and `ReviewOutcome` are not `CompletionDecision`.
6. **Finding does not grant mutation:** repair is a separate Attempt and grant.
7. **Coverage is evidence:** no-findings without explicit coverage is incomplete, never clean.
8. **No fail-open evaluation:** unavailable/malformed/timeout/context/tool/evaluator states become incomplete, blocked, failed, or nonconverged.
9. **Worktrees are not containment:** source-control collision isolation is distinct from host security.
10. **Local is topology, not proof:** local data/processes still require identity, ACL, token, secret, process, network, and recovery controls.
11. **Minimum sufficient topology:** every additional worker must justify positive marginal accepted-outcome value.
12. **Unknown is not independence:** an unknown relationship cannot satisfy a required independence relation.
13. **No silent route changes:** model/provider/helper/harness/context/tool/permission changes remain explicit lineage.
14. **Canonical knowledge is not a derived index:** vector, graph, search, and analytics stores remain rebuildable/advisory.
15. **Acquisition is component-specific:** inspection, popularity, public visibility, or root license label is not import admission.
16. **External build tools remain non-authoritative:** Spec Kit, Ponytail implementation helpers, and Cubic do not write canonical truth.
17. **S3-D cannot fork Assurance:** it emits through P0-frozen minimal envelopes and creates no second finding or authority system.
18. **Accessibility and Arabic/RTL are architectural:** never minimized as polish.
19. **Self-improving, never self-authorizing:** feedback produces candidates, never direct policy/rule/routing mutation.
20. **One object, one identity, one truth, many authorized projections.**

---

## 8. Maemar Reconciliation Recommendation

`DIRECT_V1_5_EVIDENCE`: V1.5 §6.10 deliberately preserves Maemar as the architecture-intelligence domain and requires founder reconciliation. Its mandatory capabilities include declared, implemented, build, runtime, deployment, supply-chain, and target architecture; semantic structure; APIs/events/databases/schemas; ownership/trust boundaries; impact; decisions; and drift.

Three durable arrangements remain possible:

1. Maemar as a top-level logical bounded context.
2. Maemar as a named capability domain inside Fehrest/Project Brain.
3. A split in which Fehrest owns architectural facts/provenance, AGILLE owns admissibility/constraints, and Byan owns derived architecture analytics, with Maemar retained as the named cross-domain interface.

**V2 recommendation:** option 2, with an explicit Maemar Capability Register and stable interfaces to AGILLE and Byan. This avoids a new deployable service and duplicate truth while preserving the name, ownership visibility, and capability family. The founder must decide; V2 does not answer decision 1 on the founder's behalf.

Regardless of the choice:

- architecture facts retain provenance, revision, validity interval, and authority class;
- derived graphs/reports are not canonical truth;
- architecture drift is evidence, not automatic policy;
- Maemar does not authorize effects or accept completion;
- deployment separation requires later evidence, not naming alone.

---

## 9. Work / AGILLE / Mission Runtime Reconciliation

### 9.1 Boundary questions

```text
Work             What durable outcome/coordination record exists for people and teams?
AGILLE           What engineering method, rigor, obligations, and admissibility apply?
Mission Runtime  What execution state and effects are durably true, and how do they recover?
```

V1.5 directly resolves the conceptual boundary; no duplicate founder vote is required. Final aggregate/vocabulary ratification remains decision 4.

### 9.2 State ownership

| State | Canonical owner | Notes |
|---|---|---|
| Team/Project/Work coordination | Work/governance domain | Links to missions; does not execute |
| Specification, acceptance criteria, rigor profile | AGILLE | Spec Kit artifacts are inputs/projections, not authority |
| Mission/Plan/Task/Attempt/Lease | Mission Runtime | Durable state, idempotency, checkpoints, cancellation |
| Staffing/topology decision | Edara inside Mission Runtime | Decision record, not an authority grant |
| Capability/effect decision | Nawat | Revalidated at effect time |
| Security/risk observation | AMAN | Signal only |
| Project facts/context | Fehrest | Governed knowledge; informs only |
| Review evidence/outcome | Assurance | Not completion |
| CompletionDecision | Trusted Completion under authorized policy | Produces receipt and Work projection |

### 9.3 Recovery domains

Recovery separates source/working copy, Mission state, terminal/process state, knowledge/indexes, evidence/artifacts, authority/grants, audit, and external effects. A Git reset cannot be represented as undoing an external API action, leaked credential, policy decision, or irreversible effect. Uncertainty remains first-class until reconciled.

Review attaches to an immutable target and Attempt lineage. It never mutates Work state directly. Accepted completion may update Work through an authorized projection after the CompletionDecision receipt exists.

---

## 10. Mirefa / Edara / Nawat / UWC Reconciliation

### 10.1 Four-question separation

```text
Mirefa  Which routes/components are qualified, compatible, healthy, and measured?
Edara   Who should do what, in which minimum-sufficient topology, and when?
Nawat   What may each principal do now, to which resource, for which purpose?
UWC     How is every worker invocation normalized, bounded, evidenced, and recovered?
```

Edara remains deterministic Rust-owned decision logic inside Mission Runtime for Alpha, not a separate service, second runtime, manager-model authority, or hidden subagent spawner. Model output may propose staffing; Rust validates eligibility, graph, dependency readiness, write-set conflicts, depth, budget, route compatibility, and authority preconditions before persisting a decision.

### 10.2 Universal Worker Contract minimum

Every worker assignment carries:

- worker/adapter/model/provider/harness/substrate identity and immutable version/digest;
- parent and represented principals, Assignment/Task/Attempt/Lease IDs, delegation lineage and depth;
- immutable objective, acceptance-policy digest, ReviewPlan/ContextCapsule digest where applicable;
- requested capability distinct from the Nawat-issued grant;
- data classification and egress policy;
- filesystem, writer, process, network, secret, provider, and tool profiles;
- token, monetary, time, context, request, CPU/memory, and child budgets;
- ordered/idempotent lifecycle events and durable checkpoints;
- effect receipts, output/evidence/artifact manifests, cost records, and cancellation/expiry;
- a non-authoritative completion claim: satisfied, partial, blocked, abstained, failed, or nonconverged;
- uncertain-effect, orphan, resume, reassignment, fallback, and cleanup semantics.

A child may request delegation but cannot create an authoritative child Attempt or enlarge authority. The request returns through Edara, Mission Runtime, and Nawat.

### 10.3 Role-relative measurable independence

Independence is a graph of relationships relative to the accountable builder/reviewer roles, not a count of D1–D8 labels.

| Relationship | Required evidence |
|---|---|
| Accountable principal / Attempt | Distinct principal and Attempt identities where policy requires separation |
| Model snapshot and lineage | Exact model/version plus known training/fine-tune/shared-lineage facts; `NOT_PUBLICLY_DETERMINABLE` stays unknown |
| Provider/operator/control plane | Provider, operator, tenancy/control-plane identity and shared-failure relation |
| Information set | Builder-history exposure, intermediate reasoning availability, memory/cache/retrieval overlap, context digest, and visibility timing |
| Instruction stack | System/policy/prompt/skill/rule digests and shared derivation |
| Execution harness | Adapter/harness/substrate/tool-profile identity and common-mode failure |
| Evidence-source diversity | Compiler/test/scanner/runtime/human/AI sources reported separately from reviewer identity |

Profiles state required relationships. The run records achieved relationships. `UNKNOWN` never satisfies a required relationship. Different names or providers do not prove effective independence if control plane, model lineage, context cache, prompt, harness, and evidence sources remain common.

### 10.4 Ponytail topology rule

One qualified worker is the default. Another worker is admitted only if its expected marginal accepted-outcome value remains positive after coordination time, critical-path latency, duplicated context, budget, write conflict, independence need, verification, and synthesis overhead. Dissent is preserved; it is not averaged into false certainty.

---

## 11. Fehrest / Project Brain Architecture

### 11.1 Composition

```text
Project Brain
= governed structural/semantic facts
+ human-readable knowledge and portable projections
+ source/claim/evidence/decision ledgers
+ branch- and time-aware provenance
+ runtime/operational observations
+ architecture/security/design/research knowledge
+ Memory Completeness Ledger
```

Canonical knowledge is distinct from exact/lexical indexes, symbol graphs, embeddings, vector stores, graph databases, analytics engines, and UI canvases. Those are rebuildable or advisory. Fehrest admits, supersedes, invalidates, and explains knowledge; it does not authorize effects.

### 11.2 Minimum before serious worker-quality claims

S4 must provide local deterministic ContextCapsules from files, Git, exact text search, available symbol/reference facts, requirements/ADRs/docs/evidence links, and freshness/provenance. No cloud embeddings or mandatory vector database are allowed. A claim that review is “WePLD-grade” is inadmissible until the relevant Fehrest and AGILLE context conditions are available and explicitly measured.

### 11.3 Coverage and the Memory Completeness Ledger

Fehrest surfaces known gaps: unindexed sources, unavailable cross-repository dependencies, stale ADRs, missing revisions, degraded parsers, unverified runtime evidence, unknown ownership, and unsupported claims. Assurance persists the resulting `ReviewCoverage` as immutable evidence for the exact plan/run; later index repair cannot rewrite that historical coverage.

### 11.4 Context economics

Context selection optimizes accepted outcome, not volume:

```text
ContextValue =
  Relevance × EvidenceStrength × Freshness × StructuralReachability
  × TaskSpecificity × AuthorityEligibility
  / (TokenCost + RetrievalLatency + DisclosureRisk + StalenessRisk)
```

Each selected item records source, revision, selection reason, freshness, classification, compression, disclosure decision, and omissions. Retrieval misses and expansion requests remain evidence.

---

## 12. Native Review & Assurance Architecture

### 12.1 Core position

Native Review & Assurance is a logical WePLD capability whose first full product slice is S7. Its minimal envelopes are settled in P0 and seeded deterministically in S3-D. WePLD does not require Graphite, Augment, Cubic, Qodo, CodeRabbit, Greptile, or any other SaaS to provide product review. Separately, Cubic is a required conditional **development reviewer while building WePLD**, as defined in §4.3.

### 12.2 Native surfaces

- Local working-copy/preflight review.
- Diff review.
- Commit review.
- Branch/ChangeUnit review.
- PR review.
- ChangeStack review (future UX; canonical concept now).
- Repository scan/assurance campaign.
- Mission verification.
- Security review.
- Architecture review.
- Continuous assurance.
- **Design/Accessibility Review.**
- Runtime/incident review.

Accessibility and Arabic/RTL are architecture requirements and part of assurance, never optional polish.

### 12.3 Reconciled pipeline

```text
1  Resolve immutable ReviewTarget and exact base/head/stack/environment/policy revisions.
2  Derive and validate AssuranceProfile.
3  Pin ReviewPlan, rule set, budgets, required relationships, and expected coverage.
4  Compile Fehrest ReviewContextCapsule from governed truth.
5  Run selected deterministic evidence producers outside the TCB.
6  Edara selects the minimum-sufficient Mirefa-qualified reviewer topology.
7  Reviewers run through UWC with explicit Nawat grants and isolated information sets.
8  Produce FindingCandidates and ReviewProducerRun records.
9  Validate location, evidence, reproducibility, rule binding, and context sufficiency.
10 Admit/reject/deduplicate findings while preserving conflicts and dissent.
11 Persist immutable ReviewCoverage and accepted ReviewFindings.
12 Render high-signal ReviewSynthesis/ReviewTour projections where useful.
13 Run bounded runtime verification when static evidence is insufficient.
14 Convert a repair need into a separately authorized RepairProposal/Attempt.
15 Re-run deterministic checks and independent re-review on the repaired target.
16 Persist ReviewOutcome; send evidence to Trusted Completion without collapsing authority.
```

### 12.4 Two-channel review

The machine channel may optimize recall across deterministic and specialized reviewers. Candidate validation, location checking, evidence sufficiency, rule mapping, deduplication, and conflict preservation reduce noise. The human channel receives prioritized validated findings, coverage gaps, unresolved disagreement, uncertainty, residual risk, and explicit judgment questions. A runtime-verification channel supplies falsifiable observations and limits, not a verdict.

### 12.5 Review rule governance

`ReviewRule` contains identity/version, objective, scope/path/language, provenance/rationale, examples/counterexamples, deterministic checks where possible, AI instructions, severity/evidence requirements, exceptions, owner, and admission state. Feedback produces a Byan candidate after S10; it never silently rewrites a rule or policy.

### 12.6 Minimal contract disposition

| Contract/object | V2 disposition |
|---|---|
| V1.5 `ReviewRule`, `ReviewFinding`, `EvaluationRecord`, `SecurityFinding`, `ArchitectureFinding`, `DesignFinding`, `TestResult`, `EvidenceAssessment`, `QualityPassport`, `StackAssuranceResult` | Preserve; refine fields/versioning through P0 technical work |
| `ReviewTarget` | Minimal immutable identity envelope frozen in P0 |
| `AssuranceProfile` | Versioned requirements derived from AGILLE/risk; validated in Core |
| `ReviewPlan` | Versioned reference to target, rules, producers, context, budgets, coverage and required independence |
| `ReviewContextCapsule` | Fehrest `ContextCapsule` subtype, not a duplicate context system |
| `ReviewProducerRun` | One producer execution; non-verdict; replaces ambiguous `ReviewPass` by default |
| `FindingCandidate` / `FindingDisposition` / `ReviewConflict` | Technical records behind finding admission; no duplicate finding truth |
| `ReviewCoverage` | Immutable append-only evidence bound to plan and producer-run identities |
| `VerificationRun` / `VerificationObservation` | Controlled execution/evidence records, never acceptance |
| `RepairProposal` | Proposal only; creates no mutation authority |
| `ReviewOutcome` | Assurance lifecycle outcome; mechanically distinct from `CompletionDecision` |
| `ReviewLearningCandidate` | Byan candidate at S10; governed admission required |
| `ReviewSynthesis`, `ReviewTour` | Rebuildable/content-addressed projections; do not freeze as canonical P0 domain truth |

P0 freezes semantic invariants and versioned envelopes, not an arbitrary count of fifteen schemas.

### 12.7 Finding location integrity

Every finding anchors to immutable target/base/head identity and, where possible, path plus symbol/AST identity and a contextual line window. Renames, rebases, generated files, binary files, stack restacks, and changed-line filters must produce explicit relocation or stale states. A plausible comment on the wrong revision/location is invalid evidence.

---

## 13. Review / Trusted Completion Boundary

```text
WorkerCompletionClaim
→ Mission Runtime records Attempt, effects, artifacts, lineage, cost, and uncertainty
→ Assurance evaluates criteria and persists evidence, coverage, findings, and ReviewOutcome
→ AGILLE determines lifecycle admissibility
→ Nawat revalidates apply/accept/release/publish authority
→ authorized CompletionDecision + append-only receipt
→ Work projection
```

The following never constitute completion by themselves: process exit, no exception, final message, task `DONE`, model self-score, clean Cubic review, no findings, green CI, merge, deploy, publish, `ReviewOutcome`, or verifier observation.

Valid outcomes include Accepted, Accepted with disclosed residual risk, Rejected, Blocked, Cancelled, NonConverged, and RecoveryRequired. Retry exhaustion cannot fabricate acceptance; it yields incomplete/failed/manual-review state according to policy.

Trusted Completion consumes exact target and policy revisions, acceptance criteria, immutable coverage, admitted findings and dispositions, deterministic and runtime evidence, effect receipts, route/independence lineage, repair/re-review evidence, cost/budget state, uncertainty, approvals, and residual risks. It does not trust a summary projection where underlying evidence is absent.

---

## 14. Adaptive Assurance Profiles

One AGILLE risk/rigor decision derives the AssuranceProfile; a lower label cannot be chosen merely to escape controls.

| Profile | Indicative requirements | Human/authority rule |
|---|---|---|
| LOW | Required deterministic checks; one qualified independent high-precision review where applicable; explicit coverage | Human acceptance remains required for canonical completion in Alpha |
| MEDIUM | Deterministic checks; correctness review; targeted architecture/context evaluation | Material findings/ambiguities resolved or disclosed |
| HIGH | Correctness, security, architecture, cross-boundary review; stronger independence; targeted runtime verification | Mandatory authorized judgment on residual risk |
| CRITICAL | Multiple effectively independent routes where justified; property/fuzz/model-checking/formal checks where tractable; runtime evidence; hardened provenance | Explicit authorized human/founder gate according to policy |

Admission criteria use change surface, affected authority/data/secrets, cross-repository and runtime blast radius, migration/irreversibility, dependency/supply-chain change, concurrency, provenance, novelty, rollback quality, and policy. Each profile states exact tools, required relationships, evidence, floors, budgets, and allowed exceptions.

Escalation occurs when evidence shows greater risk, missing context, disagreement, suspicious output, failed controls, or runtime divergence. De-escalation requires an authorized versioned rationale and cannot erase already observed risk. Ponytail controls reviewer count but never removes a safety-required independent relationship.

---

## 15. ReviewContextCapsule and Intent-Aware Review

The review begins from governed intent, not merely a diff or external ticket. A minimal capsule can include:

- Work/Mission objective and authorized scope;
- AGILLE specification, acceptance criteria, constraints, and non-goals;
- relevant ADRs, architecture ownership, and trust boundaries;
- changed symbols, inbound/outbound references, dependency/call graph, and cross-repository contracts;
- tests, invariants, schemas/APIs, prior findings, incidents, and runtime observations;
- exact base/head/stack/environment/toolchain/policy revisions;
- source provenance, freshness, disclosure class, omissions, and Memory Completeness gaps.

External Jira/Linear/etc. text remains untrusted evidence and possible prompt-injection/sensitive-data input. Canonical acceptance obligations must be represented in WePLD-owned contracts.

### 15.1 Mandatory context ablations

| Condition | Contents | Question |
|---|---|---|
| C0 | None beyond target/diff mechanics | Raw context floor |
| C1 | Minimal intent and acceptance criteria | Value of explicit outcome truth |
| C2 | Targeted local repository context | Value of local structure/history |
| C3 | Targeted cross-repository context | Value and disclosure cost of cross-repo reach |
| C4 | Relevant history/runtime evidence | Value of incidents, prior outcomes, traces, and temporal truth |
| C5 | Deliberately overstuffed context | Signal dilution, cost, latency, leakage, and failure threshold |

For each condition record target/task/model/harness/seed policy; capsule digest; source classes; freshness; retrieval misses; tokens; latency; monetary cost; disclosure risk; finding quality; false-success; architecture/security detection; acceptance coverage; and human burden. More context is never assumed better.

Missing acceptance criteria, stale/superseded ADRs, unavailable cross-repository dependencies, or incomplete capsule coverage remain explicit states. Reviewers may request bounded expansion; the request and resulting delta are recorded.

---

## 16. ChangeUnit, ChangeStack, and Delivery Evidence

V1.5 directly establishes the ChangeStack family in §42.3. This closes the former lineage/evidence uncertainty: `ChangeUnit`, `ChangeStack`, `ChangeDependency`, `ChangeStackRevision`, `RestackDecision`, `ChangeConflict`, `StackAssuranceResult`, `StackDeliveryDecision`, and `SpeculativeCheckReuseEvidence` are canonical future-domain concepts. Stage 3 does not reopen that decision.

The Alpha scope remains deliberately smaller than the eventual product surface:

- S9 proves one `ChangeUnit` and its delivery/quality evidence on a governed path.
- The full stacked-change authoring, restacking, dependency visualization, bottom-up review, and delivery UX remains Post-Alpha.
- A Git branch, pull request, Graphite stack, or tool-native object is an external representation, not canonical ChangeStack truth.
- ChangeStack must not duplicate Work, Mission, Attempt, ReviewTarget, or repository truth. It references their immutable identities.

### 16.1 Check-reuse invariant

Speculative reuse is permitted only when a recorded digest proves equality of every input that can affect the result: exact content/revision, base ancestry and stack dependencies, tool and configuration, environment, policy and acceptance criteria, relevant ContextCapsule, capability/network state, and declared nondeterminism. Any unknown or changed dimension invalidates reuse. A restack or conflict resolution creates a new evaluation identity even when the visible diff appears unchanged.

`StackAssuranceResult` is evidence about a stack revision. `StackDeliveryDecision` is a separately authorized delivery decision. Neither is a `CompletionDecision`.

---

## 17. Bounded Runtime Verifier

The Runtime Verifier is an evidence producer outside the physical Trusted Core. It may execute a controlled test, inspect a WePLD-owned runtime surface, or reproduce an otherwise unresolvable behavioral claim. It emits falsifiable `VerificationObservation` records, never an accept/reject/completion verdict and never ambient repair authority.

Each run records:

- immutable ReviewTarget, requested property, reason static evidence was insufficient, and authorizing policy;
- environment image/configuration digest, OS/runtime/toolchain, identity, capability leases, network policy, secret identities, and exact tested endpoints;
- replayable actions, inputs, timestamps, logs, screenshots/traces where relevant, artifacts and hashes, resource use, timeout/cancellation state, and cleanup result;
- observed behavior, tested and untested scope, uncertainty, limitations, and any divergence from the plan.

Wrong endpoint, stale target, unavailable environment, denied capability, timeout, malformed output, incomplete cleanup, or missing evidence yields `INCOMPLETE`, `BLOCKED`, or failure—never a pass.

The founder must still decide the Alpha scope. The recommended boundary is WePLD-owned desktop/core/terminal/project/review surfaces only, under explicit profiles. General browser/computer-use verification, arbitrary third-party systems, broad production access, and open-ended autonomous exploration remain Post-Alpha.

---

## 18. Byan Learning Boundary

Byan is non-authoritative analytics and learning. It cannot write operational truth, alter a `ReviewRule`, change an AssuranceProfile, admit memory, weaken an acceptance floor, or authorize an effect.

Before S10, benchmark corpora, annotations, outcomes, calibration data, and experiment records are ordinary governed infrastructure/evidence artifacts. They are not a deployed Byan runtime and do not justify a pre-S10 operational dependency.

At S10, Byan may consume validated, disclosure-safe snapshots of outcomes and produce `ReviewLearningCandidate` or optimization candidates with source lineage, confidence, affected populations, bias/contamination risks, expiry, and reproducibility evidence. Fehrest governs knowledge admission, AGILLE governs policy relevance, Assurance evaluates claims, and an authorized principal accepts or rejects any operational change. Feedback cannot directly retrain policy or silently mutate reviewer behavior.

---

## 19. AMAN and the Deterministic Evidence Mesh

AMAN observes and scans; Nawat authorizes. AMAN normalizes qualified deterministic producers—compiler/linter/test output, dependency and secret scans, structured and semantic diff evidence, architecture/security checks, and artifact provenance—into versioned evidence envelopes. It does not become a second policy store or a completion authority.

The mesh must preserve producer identity, exact revision/configuration, invocation, environment, raw-artifact digest, parser/normalizer version, location mapping, coverage, exit state, truncation, and limitations. A producer crash or parser failure cannot become “no findings.” Duplicate findings are fused only after retaining their independent source records and disagreements.

MonkeyCode is admitted only as `REFERENCE + BENCHMARK + NEGATIVE_ORACLE` at its inspected revision. Its observed empty-secret webhook acceptance, PR-URL/time-window deduplication, magic-message loop suppression, raw event logging, long-lived token exposure, and unavailable reviewer submodule become explicit negative tests. They are not patterns to port.

---

## 20. Desktop, Terminal, Browser, and Structured Execution

The Tauri desktop is an untrusted presentation/transport shell relative to authority-bearing Core state. Typed IPC, command allowlists, origin checks, schema validation, request identity, cancellation, and output limits are defense in depth; they do not grant authority. All effectful requests resolve to a principal, Work/Mission/Attempt, capability lease, target digest, and policy decision in the Core path.

Terminal execution is a structured executor plus PTY presentation:

- the structured path owns executable identity, arguments, working directory, environment allowlist, standard streams, exit/termination, resource limits, capability and network policy, and effect receipts;
- the PTY path provides interactive terminal semantics, resize, signals, encoding, and transcript evidence;
- shell text is untrusted input; quoting is platform-specific; terminal output is neither a protocol nor trusted evidence without normalization;
- a pane, process, worktree, PTY, or container ID never substitutes for an Attempt/principal/capability identity.

Browser or authenticated-session operations require a separate substrate class and per-effect authorization. Visible browser control, connector possession, or an existing login does not imply permission to read, disclose, mutate, publish, purchase, message, or accept. Session changes, navigation, downloads, uploads, clipboard, credentials, and remote-origin content are recorded and revalidated at effect time.

---

## 21. Windows Containment Qualification

V1.5 elevates Windows containment to P0 and explicitly names Job Objects, restricted tokens/ACL/AppContainer, HCS/hcsshim, Hyper-V/Windows Sandbox/LiteBox, and Windows APIs. Stage 3 strengthens this into an adversarial qualification, not a paper checklist. A trusted Rust path check, worktree, PTY, Tauri ACL, or process boundary is not containment of a hostile worker.

### 21.1 Required property matrix

Every proposed Windows execution profile must state and test:

1. **Principal and token confinement:** restricted token construction, integrity level, privileges, groups/SIDs, elevation/UAC behavior, service-account boundary, impersonation, child inheritance, and credential isolation.
2. **Process-tree control:** Job Object assignment before untrusted execution, nested jobs, breakaway flags, grandchildren, detached processes, shell/script hosts, GUI processes, debugger/injection surfaces, handle inheritance, termination, accounting, and race-free startup.
3. **Filesystem confinement:** canonical path and ACL behavior, junctions/symlinks/reparse points, mount/volume changes, hard links, alternate data streams, device paths, 8.3/case/Unicode normalization, UNC/network paths, TOCTOU swaps, temp locations, locks, quotas, and project-boundary escape.
4. **Network confinement:** IPv4/IPv6, TCP/UDP, DNS, loopback, local subnets, proxies, VPN interfaces, raw sockets where applicable, process identity binding, dynamic child processes, WFP lifecycle, policy-update races, telemetry, and fail-closed behavior when enforcement setup fails.
5. **Credentials and providers:** no ambient user tokens, browser/session stores, SSH/Git/cloud credentials, DPAPI material, named-provider secrets, or inherited environment secrets; only short-lived scoped leases with use receipts and revocation.
6. **IPC and kernel-object confinement:** named pipes, mailslots, RPC/COM, window messages, clipboard, shared memory, mutex/events, inherited and duplicated handles, ConPTY handles, local ports, and cross-session interaction.
7. **Resource resistance:** CPU, memory, process, thread, handle, disk, output/log, file-count, recursion, decompression/archive, fork/process, and time bombs; backpressure and bounded evidence capture.
8. **Atomic lifecycle:** enforcement is established before executable-controlled code; partial setup aborts cleanly; cancellation, crash, host restart, stale state, orphan discovery, reboot, replay, idempotent cleanup, and reconciliation are tested.
9. **Command diversity:** direct executables, `cmd.exe`, PowerShell, batch/scripts, interpreters, build tools, installers, child shells, ConPTY and non-PTY paths, unusual quoting/encoding, and executable resolution are covered.
10. **Evidence and performance:** each denial/allow decision and teardown is attributable without leaking secrets; startup, interactive latency, throughput, memory, cleanup, and degraded/failure modes are measured on supported Windows versions.

The current Codex Windows mechanisms are useful source/test oracles, not a qualified WePLD sandbox: WFP configuration may continue after failure and known URL/ConPTY smoke-test gaps must remain negative cases. WezTerm `portable-pty` is terminal plumbing, not token/job/network confinement. Tauri IPC is transport defense in depth.

`B-WIN-001` remains scoped: it blocks execution of an untrusted local Alpha worker. It does not block P0 planning, contract work, or an Alpha explicitly limited to no untrusted worker. Deterministic tooling in the trusted developer workflow is permitted only under a disclosed profile whose input-trust class is explicit; processing untrusted project content is an execution-risk class and requires evidence for that class. Founder authorization must choose bounded qualification or the no-untrusted-worker limitation before S3 exits.

---

## 22. Data, Network, Egress, and External Reviewer Policy

The Core path must function `LOCAL_ONLY`. Network access is an explicit capability, not an ambient assumption. Nawat policy binds destination/service class, data classes, purpose, payload digest or bounded derivation, identity, time, budget, retention expectation, approval, and revocation. AMAN records observations; it does not decide.

Cubic is now an actual independent reviewer in the WePLD development workflow when the governing data-egress policy permits the exact code/context disclosure. It remains non-authoritative and is not a runtime dependency. When egress is denied, unavailable, or outside the approved disclosure envelope, record `NOT_RUN_DATA_EGRESS_DENIED`, `NOT_RUN_UNAVAILABLE`, or the precise non-run reason—never `PASS` and never silent fallback.

Every external model/reviewer route records provider, operator/control plane, model/version lineage, harness and instruction stack, information sources, memory/cache/retrieval state, region where relevant, retention/training posture, tool access, fallback behavior, and exact disclosed artifact digests. Provider assertions are vendor-reported until independently verified. Secrets, customer data, private repositories, security findings, and cross-repository context default to non-egress unless explicitly authorized.

External tickets, webhook payloads, PR comments, repository content, generated output, and connector data are untrusted and possibly prompt-injecting. They cannot expand scope, capabilities, context disclosure, or acceptance criteria.

---

## 23. PR #11 — Replacement-First Supersession

Live evidence at the review window shows PR #11 open, draft, unmerged, cleanly mergeable, and one commit ahead of current `main`; its head is `68cab399748c5c103b8f96380da69fdffca4d3fe`. Its successful documentation check is evidence about that workflow, not architectural ratification. It has no independent submitted review or review thread.

The canonical direction remains **do not merge unchanged**. The corrected disposition is replacement-first:

1. produce and ratify the replacement canonical plan/records outside the PR;
2. create a durable provenance map from each useful PR #11 artifact/decision to its successor or explicit rejection;
3. preserve immutable head/base identities and any required archival reference;
4. add cross-links in the authorized governance channel; then
5. close PR #11 as superseded, only after founder authorization and only in a later mutation-authorized task.

Leaving an obsolete draft open indefinitely is not a governance mechanism. This report performs none of those GitHub mutations.

---

## 24. PR #1 — Donor Ledger, Archive, and Supersession

Live evidence shows PR #1 open, draft, unmerged, non-mergeable/dirty, with head `d5ef318468b6c35df3c14c1c5f72beb1191baf29`, 46 commits and 142 changed files. Its recorded base is stale relative to live `main`. The successful Rust check and four author remediation comments are useful evidence, not independent acceptance or authority to merge.

PR #1 remains an implementation-evidence donor, never a wholesale merge candidate. Before disposition, create a path- and concept-level salvage ledger:

| Disposition | Meaning |
|---|---|
| `KEEP_EVIDENCE` | Preserve tests, failure cases, decisions, or measurements without importing implementation |
| `PORT` | Reimplement a bounded mechanism with exact provenance/rights/tests |
| `ADAPT` | Rework a suitable component behind current contracts and controls |
| `REWRITE` | Preserve requirement/evidence but replace implementation |
| `SUPERSEDE` | A later canonical artifact fully replaces it with cross-link |
| `REJECT` | Do not reuse; record reason and negative oracle if valuable |

For every kept item record source commit/path/blob digest, authoring/license provenance, affected contracts, security/privacy implications, dependencies, current relevance, validation evidence, destination, and replacement/exit plan. Preserve an archival immutable ref if required for provenance, establish durable cross-links, and then close the draft as superseded only after founder approval in a separately authorized task. No rebase, merge, branch, comment, or closure occurs here.

---

## 25. Reconciliation of Former Decisions and Blockers

Direct V1.5 inspection and the Stage-2 correction close several false or stale governance questions:

| Former item | Stage-3 status | Basis |
|---|---|---|
| Evidence access / V1.5 inspection | `CLOSED` | Full direct inspection; exact path/hash recorded in §0 |
| ChangeStack existence and lineage | `CLOSED` | Direct V1.5 §42.3 and final discovery sweep |
| Design/Accessibility Review existence | `CLOSED` | Direct V1.5 constitutional/native-review requirements |
| Core state hierarchy, Spec/AGILLE split, terminal structure, evidence-not-verdict | `TECHNICALLY_SETTLED` | Canonical architecture plus Stage-3 corrections; implement through contracts/tests |
| Assurance contract count and benchmark corpus size | `P0_TECHNICAL_WORK` | Must be designed/validated; not founder votes or external blockers |
| Independence topology and benchmark statistics | `P0_TECHNICAL_WORK` | Corrected requirements are testable design obligations |
| Source universe blanket admission | `RETRACTED` | Acquisition is component/path/version specific and incomplete |

Only the ten questions in §37 remain founder/governance decisions. Only the two scoped blockers in §38 remain current blockers.

---

## 26. Reconciled Conflict Ledger

| Conflict | Controlling resolution |
|---|---|
| Stage 1 treated V1.5 as unavailable | V1.5 is directly inspected and controls as the latest canonical reference, subject to newer explicit founder direction |
| Stage 1 treated ChangeStack lineage as unverified | Direct V1.5 §42.3 establishes it; exact implementation remains later technical work |
| Stage 1 questioned Design/Accessibility Review | Direct V1.5 retains accessibility/RTL/design assurance; close the decision |
| V1.5 has an earlier §26.1 roadmap and later §42.21 roadmap | The later final-discovery sweep controls: S1–S10, Fehrest S4, Spec Kit/AGILLE S5, first full Review/Assurance S7; Stage 3 adds non-primary S3-D |
| V1.5 benchmark arms differ from Stage-3 arms | Newer founder direction controls: D0, A raw, B governed rules, C Fehrest+AGILLE, D full topology; record the change rather than misquoting V1.5 |
| V1.5 independence list is incomplete for adversarial assurance | Preserve it as a floor and apply the role-relative Stage-3 relation graph in §10 |
| V1.5 names only part of the proposed review vocabulary | Use proposed envelopes conservatively; do not attribute new names to V1.5 or create duplicate canonical truth |
| V1.5 treats Spec Kit/Ponytail mainly as future native capability and Cubic as behavior oracle | Current founder direction additionally mandates their bounded development-workflow use now; product internalization remains later |
| Public live repository conflicts with proprietary/Private posture | `B-GOV-001`; founder-controlled containment/governance decision required before implementation publication |
| Stage 1 called OpenReview definitively license-blocked | Correct to `RIGHTS_UNKNOWN / LEGAL_REVIEW_REQUIRED`; a README assertion is not an operative grant |

---

## 27. Component Acquisition and Build-vs-Reuse Gate

`SOURCE_ACQUISITION_COMPLETENESS = PARTIAL / PREVIOUSLY_OVERCLAIMED`.

`NO_COMPONENT_IMPORT_ADMITTED` by this planning report. Repository-level licenses and reference-level study are not path-level admission. P0 must create a record for every actual S1 or S3-D component and its transitive/runtime surface before code reuse.

### 27.1 Mandatory acquisition record

Each record includes exact repository, immutable revision, selected paths and blob hashes, upstream lineage, tests/fixtures, dependencies and build scripts, license/NOTICE/attribution, advisories and security posture, platform/maintenance evidence, data/network/effect surface, intended `COPY | VENDOR | EMBED | PORT | PACKAGE | REFERENCE | REJECT` disposition, contract boundary, delta from upstream, admission/negative/performance/security tests, SBOM provenance, update/replacement/exit plan, reviewer and decision authority.

Custom machinery is permitted only for `NO_SUITABLE_COMPONENT`, `LICENSE_BLOCKED`, `SECURITY_BLOCKED`, `ARCHITECTURE_INCOMPATIBLE`, `PERFORMANCE_BLOCKED`, `PORTABILITY_BLOCKED`, or a documented `WEPLD_DIFFERENTIATOR`. “Easy to generate” is invalid.

### 27.2 Current exact-source ledger

| Source @ inspected revision | Rights/evidence state | Stage-3 disposition |
|---|---|---|
| `alibaba/open-code-review@4068a4bd25a48df12d3ec89f70adfea63151593c` | Apache-2.0 at repository level; exact candidate paths/dependencies still need admission | Path-level audit candidate; deterministic/agent orchestration reference only now |
| `reviewdog/reviewdog@d8462283c7315f1a47e8edd140aeffd0f0ca28ea` | MIT; copying/translating schema, code, or fixtures is fact-specific | RDFormat/diff-filter behavior reference; any derivation/copy is `LEGAL_REVIEW_REQUIRED` with exact blobs |
| `The-PR-Agent/pr-agent@20bc0fe8ae7c1494c0be580f7ceb35a1c45e5741` | MIT repository evidence; provider/VCS/dependency surface separate | Reference/test oracle for compression and workflow; no runtime dependency admitted |
| `vercel-labs/openreview@672deb21e70e471e0536d5ad7a67c14b8359e97e` | No operative grant established; README says MIT | `RIGHTS_UNKNOWN / LEGAL_REVIEW_REQUIRED`; behavior reference only; reject code reuse now |
| `augmentcode/context-connectors@f7d6472ae626c98fd768f64cdfd6160145eefa77` | MIT repository evidence; service dependency exists | Connector/index/ignore reference; reject Augment service dependency as Fehrest truth |
| `chaitin/MonkeyCode@12107c7bfc3bb0ef97e2fd0709411a3a6afda9cb` | AGPL-3.0; linked `OhMyAgent@a455e6f346c42cdb78c8943bbeacf935d02c5a5a` unavailable and rights unknown | `REFERENCE + BENCHMARK + NEGATIVE_ORACLE`; reject proprietary copy/vendor/embed/port absent separate approved rights strategy |
| `astral-sh/ruff@8f11b10b926b1625cf35a5babb44854e2bbd423d` | MIT repository evidence | Qualified local deterministic producer candidate; package/path admission still required |
| `biomejs/biome@40dad299ae90e045b55a219a3c0f9e6cca0e153f` | Apache-2.0 repository evidence | Qualified local deterministic producer candidate; package/path admission still required |
| `ast-grep/ast-grep@5aa00e1dd5e0077589a6c0c23c640e39947403ec` | MIT repository evidence | Semantic-query producer candidate outside minimal TCB; do not auto-embed |
| `Wilfred/difftastic@e23b7d4ff8fa1eabe8236d3b7c20ac5507c888ee` | MIT repository evidence | Structured-diff behavior/reference candidate |
| `git-town/git-town@8c5aa8834c22db5beb0ddb16fe5aa224bdd1bccf` | MIT repository evidence | ChangeStack behavior/mechanism reference only |
| `ejoffe/spr@0767a458e50fa1f7ae203b73e50298ab201c80bb` | MIT repository evidence | ChangeStack behavior/mechanism reference only |
| `ezyang/ghstack@f4e9df551eda204bc95b4329870ea304bd20fbb0` | MIT repository evidence | ChangeStack behavior/mechanism reference only |
| `timothyandrew/gh-stack@d6aa8192ed4cf905826abb2ab97c51b8aaaafa4c` | Archived; repository rights evidence must be carried in its record | Historical reference only; no dependency |
| `amElnagdy/delegate-skills@f9f2528525b820e7fd24724f87d6821c0e272947` | MIT repository evidence | UWC/schema/test donor only; never authority or runtime admission by implication |
| `petgraph/petgraph@ed714652ab4576104e506c096b6ed9f5128613a7` | MIT/Apache-2.0 repository evidence | Strong direct graph-library candidate with minimal features; transitive/admission gate remains |

Supplemental exact-revision source inspection also narrows platform reuse: Tauri remains the shell dependency and typed IPC defense in depth, not the authority kernel; Codex Windows source is a selective-port/test oracle with known fail-open/gap cases; WezTerm `portable-pty` is usable only behind a WePLD-owned launcher and containment boundary. Their actual S1/S3 admission records must capture the full inspected SHAs and exact paths before reuse; this report deliberately does not convert abbreviated audit notes into false exact pins.

### 27.3 Proprietary products

Graphite, Augment, and Cubic are product-behavior evidence and may also have separately identified source artifacts. Observation alone creates no source-acquisition right; the founder-provided authorization is a distinct rights basis and must be recorded where invoked. Every actual artifact remains individually pinned with upstream-license, third-party-rights, NOTICE/attribution, advisory and provenance lineage. No hosted object may become canonical WePLD authority.

---

## 28. P0 Founder Package and Exit Deliverables

P0 is documentation, specification, evidence, governance, and experiment design only. It authorizes no product implementation, dependency installation, source import, repository mutation, or external effect.

| ID | Deliverable | Exit condition |
|---|---|---|
| `P0-D1` | Direct V1.5 reconciliation record | Exact artifact path/hash, authority precedence, contradictions, ChangeStack, Design/Accessibility, roadmap, decisions, and blockers are traceably reconciled |
| `P0-D2` | Canonical architecture/ownership record | Final vocabulary and aggregate ownership, Maemar disposition, logical/deployable boundaries, authority graph, anti-fork invariants, UCAP owner-label resolution, and pre-Mission executor-record semantics are founder-approved; S3 uses `CommandRun`/`ProcessTreeRecord`, not a native `Attempt` |
| `P0-D3` | Minimal Assurance/Trusted Completion boundary | Semantic envelopes and transitions are specified; `ReviewCoverage` is immutable evidence; projections are distinguished; `ReviewOutcome != CompletionDecision` is mechanically testable; physical TCB is minimal |
| `P0-D4` | TCB and Windows security plan | Trusted/untrusted placement, input-trust classes, the §21 qualification matrix, fail-closed profiles, atomic lifecycle, evidence requirements, and no-untrusted-worker fallback are explicit and falsifiable; trusted tools processing untrusted project content require a profile qualified for that threat class |
| `P0-D5` | Component-specific acquisition ledger | Actual S1 and S3-D dependencies/oracles have exact revision/path/blob/rights/security/test/SBOM/exit records; MonkeyCode negatives included; no blanket donor admission |
| `P0-D6` | Benchmark laboratory and corpus protocol | D0/A/B/C/D, exactly twenty metric families `M-01..M-20`, strata, floors/budgets/non-inferiority/Pareto/statistics, `CTX-C0..CTX-C5` context ablations, `CORPUS-C0..CORPUS-C4` lifecycle, and Cubic/native/combined comparison are approved |
| `P0-D7` | Governance, roadmap, and development-method contract | Visibility/IP disposition, PR #11/#1 successor posture, ADR/history namespacing, ten slices plus S3-D, and the always-on Spec Kit/Ponytail FULL/Cubic workflow are approved with narrow authorizations |

P0 exit requires approved falsifiable protocols, not completion of the Windows experiment or final corpus. Unavailable evidence is disclosed with a bounded acquisition plan; it is never marked passed.

---

## 29. Corrected Ten-Slice Roadmap and Non-Primary S3-D Gate

`PRIMARY_SLICES_COUNT = 10`. S3-D is a non-primary Assurance Seed gate between S3 and S4; it is not an eleventh slice and creates no new authority domain.

### 29.1 Shared build protocol for every code-changing slice

Before any code-changing slice begins, an authorized development packet must run the external build methodology:

1. **Spec Kit:** constitution → specify → clarify → plan → checklist → analyze → tasks → implement. These are controlled development artifacts, not canonical product truth by themselves. Record the exact release/tag/commit where applicable, workflow/template version or digest, configuration, and provenance.
2. **Ponytail FULL:** challenge every proposed dependency, abstraction, privilege, worker/service, data copy, deployment boundary, recovery mechanism, evidence path, accessibility impact, and authority-bearing type. “Minimum sufficient” cannot remove a protected safety, recovery, accessibility, evidence, or authority concern. Record the exact release/version/commit where applicable and the ruleset/skill/configuration digest with `PONYTAIL_MODE = FULL`.
3. **Cubic independent review:** run on the exact change when the approved egress envelope permits. Record CLI/client version, review configuration/profile, observable service/policy snapshot where applicable, data-egress classification, retention/disclosure qualification, exact target/revision and all findings. If denied or unavailable, record the exact `NOT_RUN_*` state; never infer pass. Cubic is non-authoritative. Exceptional acceptance without the normally required Cubic route requires an explicit waiver by the same authorized acceptance authority that may decide G9, an independently qualified substitute review route, and a recorded residual limitation.
4. **WePLD-owned controls:** deterministic checks, applicable security and negative tests, independent human/Assurance review, evidence admission, and authorized slice exit remain mandatory. An external tool cannot grant acceptance.

**Bootstrap rule for pre-native development evidence.** Before a corresponding WePLD-native subsystem exists and has been accepted, its obligation is represented by immutable external development evidence with stable identifiers, hashes/digests, exact scope, authority, provenance, acceptance obligations, budgets where applicable, recovery/rollback obligations, and evidence references. Such evidence MUST NOT be described as an already-native `Work`, `Mission`, `Attempt`, `ContextCapsule`, or Nawat grant/record when that product capability does not yet exist. From the first accepted slice that implements the relevant native capability, subsequent slices MUST use the WePLD-native representation where applicable. This creates no new canonical aggregate: it preserves no ambient authority, no fabricated canonical identity, no false self-hosting claim, and full traceability from S1 onward.

Every slice must additionally have an approved component ledger, an acceptance policy or its immutable pre-native equivalent, budget, rollback/recovery plan, evidence retention, accessibility/RTL review where user-facing, and no unresolved scope expansion. Native Work/Mission/Attempt, ContextCapsule, and Nawat records are required only from the first accepted slice that makes each corresponding native representation available and applicable.

The `EXPECTED_PATHS` below are provisional physical-placement hypotheses for planning. P0 vocabulary/ownership and repository inventory may refine them before implementation; listing a path does not authorize creating it.

### 29.2 S1 — Desktop ↔ Rust Trusted Core Handshake

| Field | Reconciled plan |
|---|---|
| `PURPOSE` | Establish one typed, versioned, observable request/response/event channel between the Tauri desktop and a separate Rust Core process |
| `USER_VALUE` | A desktop shell can connect, report health/version/capabilities, cancel a request, and fail clearly without hidden authority |
| `ARCHITECTURE_DELTA` | Core owns authority-bearing validation/state; shell renders projections; correlation, idempotency, schema negotiation, bounded payloads, cancellation, liveness, and restart semantics are introduced |
| `OWNER` | Trusted Core owns protocol validation and state; Desktop owns presentation/transport only |
| `DEPENDENCIES` | P0-D2/D3/D5/D7, resolved repository-governance authority, Rust/Tauri toolchain and qualified local IPC selection |
| `DONORS` | Tauri shell/typed-IPC mechanics; Rust ecosystem components only after exact S1 acquisition records; prior handshake evidence as test oracle |
| `DISPOSITIONS` | `PACKAGE` or narrow `ADAPT` only after admission; reject Tauri ACL/IPC as Nawat authority; no broad source import |
| `TRUST` | Desktop/UI/webview and all incoming payloads are untrusted; minimal Core validation/state/receipts are trusted |
| `AUTHORITY` | Handshake conveys a principal-bound request; it grants no file/process/network/repository authority by connection alone |
| `DATA` | Health, version, capability descriptors, bounded request/event payloads; no secrets or project content required for the base handshake |
| `NETWORK` | `LOCAL_ONLY`; no hosted control plane; local transport endpoint authenticated/bound and origin constrained |
| `PLATFORM` | Windows-first with cross-platform compile/contract plan; IPC/path/encoding/restart behavior tested per OS |
| `FAILURE` | Version mismatch, spoofed/stale peer, duplicate/replayed request, oversized/malformed payload, partial response, crash/restart, cancellation race, backpressure, event loss |
| `NEGATIVE_TESTS` | Unknown command, schema downgrade, forged principal/correlation, duplicate effect, invalid origin, flood/oversize, Core unavailable, desktop crash, Core crash, stale socket/endpoint |
| `ACCEPTANCE` | Typed round-trip and cancellation succeed; malformed/unauthorized inputs fail closed; restart/reconnect preserves no false authority; evidence identifies exact binaries/protocol |
| `BENCHMARKS` | Startup/handshake latency, steady request latency/throughput, memory, backpressure, crash recovery, schema-validation and denial cost |
| `NON_GOALS` | Project open, terminal, AI worker, Fehrest, review, repair, completion, cloud sync |
| `DEFERRED` | Rich streaming UI, remote clients, collaboration, auto-update, generalized plugin transport |
| `EXPECTED_PATHS` | `apps/desktop/**`, `crates/core/**`, `crates/contracts/**`, `crates/ipc/**`, `tests/desktop_core/**` |
| `MIGRATION` | Versioned protocol envelopes; no silent downgrade; compatibility window explicitly bounded |
| `RECOVERY` | Restart/reconnect with correlation and idempotency reconciliation; stale endpoints removed safely; no in-flight request fabricated complete |
| `EXIT` | S1 evidence packet passes Spec Kit/Ponytail/Cubic policy, contract/security/negative/performance tests, accessibility baseline, and authorized review |
| `FOUNDER_AUTHORIZATION_REQUIRED` | `YES`—P0 ratification, governance resolution, and specific S1 implementation authorization |

### 29.3 S2 — Open Project, Project Doctor, Local Identity and Storage

| Field | Reconciled plan |
|---|---|
| `PURPOSE` | Open an explicitly selected local project, identify it durably, diagnose readiness, and persist minimal local state without granting execution authority |
| `USER_VALUE` | The founder sees what project is open, why it is healthy/degraded/blocked, and how to recover without hidden mutation |
| `ARCHITECTURE_DELTA` | Adds Project identity, source/root observations, versioned local store, Doctor findings, storage migration/backup, and read-only discovery contracts |
| `OWNER` | Core Project/identity/storage modules own canonical local records; Doctor emits evidence; UI projects it |
| `DEPENDENCIES` | S1, P0 vocabulary/aggregate ownership, data-classification/retention rules, storage and filesystem component admission |
| `DONORS` | Git/filesystem/storage libraries and prior Project Doctor behavior only after exact admission; no external project object becomes truth |
| `DISPOSITIONS` | Prefer qualified packages for commodity parsing/storage; custom logic only for WePLD identity/authority invariants |
| `TRUST` | User-selected path is intent evidence, not proof; filesystem, repository metadata, config, symlinks/reparse points, and external files are untrusted observations |
| `AUTHORITY` | Open exposes bounded read discovery for the selected scope; write, install, execute, network, credential, and repository effect capabilities are structurally absent at S2. This is not a pre-Nawat authorization engine or policy grant and must not become a second authority point when Nawat appears |
| `DATA` | Local path identity, repository/worktree/ref observations, Doctor results, storage schema/version, classification and provenance; secrets excluded/redacted |
| `NETWORK` | `LOCAL_ONLY`; remotes recorded as strings/evidence without contact unless later separately authorized |
| `PLATFORM` | Windows path/reparse/ACL/UNC semantics plus cross-platform normalization; long paths, Unicode and case behavior tested |
| `FAILURE` | Missing/inaccessible/moved root, identity collision, repository corruption, reparse escape, stale observation, locked/corrupt store, migration interruption, disk full |
| `NEGATIVE_TESTS` | Root swap/TOCTOU, junction outside scope, malicious config, huge tree, binary/permission traps, stale ref, corrupt DB, interrupted migration, backup restore mismatch |
| `ACCEPTANCE` | Exact project identity and scope are stable/explainable; Doctor separates observation from decision; store migration is atomic/recoverable; no unauthorized write/exec/network occurs |
| `BENCHMARKS` | Open/scan latency by tree size, memory/I/O, cache correctness, change detection, Doctor precision/noise, migration/recovery time |
| `NON_GOALS` | Full Fehrest indexing, terminal execution, dependency installation, remote fetch, auto-fix, multi-project aggregation |
| `DEFERRED` | Cross-repository graph, shared/team storage, cloud sync, advanced watch/index services |
| `EXPECTED_PATHS` | `crates/project/**`, `crates/doctor/**`, `crates/storage/**`, `crates/identity/**`, `tests/project_doctor/**`, storage migrations |
| `MIGRATION` | Versioned schema with preflight, backup, forward migration and explicit unsupported downgrade |
| `RECOVERY` | Restore last valid store or rebuild projections from source-authoritative local state; quarantine corrupt records; preserve audit evidence |
| `EXIT` | Open/Doctor/store property, adversarial path, migration, recovery, performance and UI accessibility tests pass under approved method packet |
| `FOUNDER_AUTHORIZATION_REQUIRED` | `YES`—separate S2 implementation authorization after S1 exit |

### 29.4 S3 — Terminal Fabric, Trusted Process Ownership, and Windows Qualification Foundation

| Field | Reconciled plan |
|---|---|
| `PURPOSE` | Provide a structured, principal-bound executor and PTY terminal with truthful process lifecycle, while building the evidence needed for bounded Windows confinement |
| `USER_VALUE` | Commands run visibly and cancellably; ownership, environment, limits, exit, and failure are explicit; no orphan is called complete |
| `ARCHITECTURE_DELTA` | Adds principal-bound `CommandRun` / `ProcessTreeRecord` execution records, launcher, structured argv/env/cwd, PTY adapter, output limits, cancellation, reconciliation, effect receipts, and Windows profile harness; no native `Attempt` is created in S3 |
| `OWNER` | Mission Runtime owns command/process lifecycle; Nawat owns capabilities/effect-time authorization; Terminal owns presentation; Core persists receipts; canonical `Mission`/`Task`/`Attempt` semantics remain for their later native slice |
| `DEPENDENCIES` | S2 identity/storage, P0-D4/D5, §21 protocol, Windows profile choice, accepted PTY/process components |
| `DONORS` | WezTerm `portable-pty` for PTY mechanics only; Codex Windows code as selective-port/test oracle; Windows APIs/windows-rs/HCS candidates after path-level audit |
| `DISPOSITIONS` | PTY behind WePLD launcher; port only admitted containment primitives; reject worktree/PTY/Tauri ACL as sandbox and reject WFP continue-on-failure |
| `TRUST` | Worker/command/shell/output/project files are untrusted; launcher, policy verification, minimal state and receipts are trusted; containment claim is profile-specific |
| `AUTHORITY` | Every spawn/effect requires principal, `CommandRun` identity, executable/argv/cwd/env digest, capability lease and budget; possession of terminal or credential is not authority |
| `DATA` | Commands, bounded environment, transcripts, exit/resource/containment evidence; secrets referenced by lease identity and redacted from logs |
| `NETWORK` | Denied by default; per-profile WFP/stronger substrate qualification required; enforcement failure aborts spawn |
| `PLATFORM` | Windows qualification foundation is mandatory; cross-platform adapters cannot dilute Windows properties; `cmd`, PowerShell, direct and ConPTY paths covered |
| `FAILURE` | Pre-launch partial setup, breakaway/orphan, token/ACL/WFP failure, handle/IPC leak, shell quoting, output/resource bomb, cancellation race, crash/reboot/stale state, teardown failure |
| `NEGATIVE_TESTS` | Full §21 matrix including elevation, reparse/TOCTOU/device/UNC, IPv4/IPv6/DNS/UDP/TCP/loopback/proxy, credentials, pipes/shared memory/ConPTY, bombs and reboot reconciliation |
| `ACCEPTANCE` | Structured execution and PTY lifecycle are truthful/idempotent; unqualified profiles make no sandbox claim; either a bounded Windows profile passes or Alpha remains no-untrusted-worker |
| `BENCHMARKS` | Spawn/interactive latency, throughput, output/backpressure, resource overhead, denial cost, cleanup/recovery time, containment false-allow/false-deny by profile |
| `NON_GOALS` | General autonomous worker, broad browser/computer control, arbitrary container orchestration, completion, review/repair |
| `DEFERRED` | Stronger VM/HCS/Hyper-V profiles, remote execution, multiplexer collaboration, generalized scheduler |
| `EXPECTED_PATHS` | `crates/execution/**`, `crates/terminal/**`, `crates/runtime/**`, `crates/nawat/**`, `crates/windows_containment/**`, `tests/windows_qualification/**` |
| `MIGRATION` | Profile/version IDs and launcher contracts; PTY provider replaceable; no persisted claim upgraded without requalification |
| `RECOVERY` | Durable command/process ledger (`CommandRun` + `ProcessTreeRecord`), orphan discovery, lease revocation, kill/reconcile, idempotent cleanup, crash/reboot recovery evidence; later `Attempt` records reference these immutable execution records rather than reinterpret them |
| `EXIT` | Trusted-process foundation passes; §21 evidence supports the authorized profile or records no-untrusted-worker Alpha; all method/security/performance gates pass |
| `FOUNDER_AUTHORIZATION_REQUIRED` | `YES`—S3 implementation authorization and founder choice on Windows qualification vs no-untrusted-worker Alpha |

### 29.5 S3-D — Assurance Seed Gate (Non-Primary)

| Field | Reconciled plan |
|---|---|
| `PURPOSE` | Seed deterministic, fail-clean Assurance evidence and benchmark mechanics without creating the full Assurance product or a new authority domain |
| `USER_VALUE` | Early changes receive reproducible producer and coverage evidence before native AI review exists |
| `ARCHITECTURE_DELTA` | Adds versioned producer/evidence envelopes, ReviewTarget minimum, ReviewPlan reference, `ReviewProducerRun`, immutable `ReviewCoverage`, deterministic adapters, diff/location fixtures, fail-clean tests, and benchmark manifest/runner seed |
| `OWNER` | Assurance contracts and test infrastructure; explicitly not Byan and not the entire logical Assurance subsystem inside the TCB |
| `DEPENDENCIES` | P0-D3/D5/D6/D7, S2 artifact storage, S3 trusted deterministic execution foundation; untrusted producer execution **or trusted producers over untrusted project content** requires a profile explicitly qualified for that input/execution threat class |
| `DONORS` | Ruff, Biome, ast-grep, Difftastic, open-code-review, reviewdog, pr-agent, OpenReview, MonkeyCode and useful PR #1 fixtures, each under its exact record |
| `DISPOSITIONS` | Deterministic tools are candidates only; open-code-review/pr-agent reference; reviewdog derivation/copy requires exact-artifact legal review; OpenReview rights unknown/legal review; MonkeyCode reference/benchmark/negative oracle; inspection admits nothing |
| `TRUST` | Producers, parsers and their findings are untrusted evidence sources; only minimal envelope validation/admission/state/receipts are trusted |
| `AUTHORITY` | Producers and findings have zero mutation, verdict, completion, grant, rule or policy authority |
| `DATA` | Fixtures/corpus are evaluation data; runner is test infrastructure; coverage/run records are immutable evidence; no Byan operational knowledge |
| `NETWORK` | Deterministic route `LOCAL_ONLY`; external Cubic is governed separately by the build-workflow egress gate |
| `PLATFORM` | Windows 11 deterministic path first; exact tool/platform limitations appear in coverage; no untested cross-platform claim |
| `FAILURE` | Timeout, crash, malformed/partial output, missing tool, digest mismatch, unscanned file, parser error or denied capability yields incomplete/blocked evidence, never clean |
| `NEGATIVE_TESTS` | Interrupt/resume, unpinned tool, glob/rule conflict, binary/generated content, location drift, missing coverage, malformed producer output, false zero-findings, rejected/unlicensed import |
| `ACCEPTANCE` | Pinned replay produces equivalent evidence; every target has immutable coverage and explicit gaps; fail-clean/admission suites pass; prohibited AI/Byan/completion/repair capability absent |
| `BENCHMARKS` | D0 mechanism baseline, CORPUS-C0 fixtures, runner reproducibility, evidence size, CPU/memory/I/O/latency and failure-state truthfulness |
| `NON_GOALS` | AI review, Byan, Trusted Completion, repair, ReviewSynthesis/Tour as canonical truth, independent reviewer topology, broad Assurance TCB |
| `DEFERRED` | Full native review to S7, repair/completion to S8, Byan to S10, rich ReviewTour projection |
| `EXPECTED_PATHS` | `crates/assurance/contracts/**`, `crates/assurance/producers/**`, `tests/assurance/fixtures/**`, `benchmarks/review/**`; explicitly no `crates/byan/**` ownership |
| `MIGRATION` | Evidence/coverage envelopes version from first emission; immutable records are superseded, never rewritten; producers remain replaceable |
| `RECOVERY` | Resume only from exact target/manifest/checkpoint digests; discard or quarantine unverifiable partial output; retain failure evidence |
| `EXIT` | Only the permitted seed exists; all method, component, deterministic, fail-clean, reproducibility, data and authority-negative gates pass |
| `FOUNDER_AUTHORIZATION_REQUIRED` | `YES`—specific non-primary gate authorization plus component-specific S3-D admissions |

### 29.6 S4 — Fehrest Minimum / Project Brain Bootstrap

| Field | Reconciled plan |
|---|---|
| `PURPOSE` | Build deterministic, provenance-bearing local project context sufficient for later planning, work and review |
| `USER_VALUE` | Files, symbols, requirements, ADRs, tests and evidence can be found with freshness and source links rather than guessed |
| `ARCHITECTURE_DELTA` | Adds files/Git/exact-text index, qualified symbol/reference adapters, requirement/ADR/evidence links, retrieval manifests and deterministic ContextCapsule inputs |
| `OWNER` | Fehrest owns admission/retrieval/provenance/freshness; source systems remain authoritative; consumers own their decisions |
| `DEPENDENCIES` | S2 identity/storage; S3/S3-D evidence and deterministic execution where applicable; final Maemar relationship decision |
| `DONORS` | gix, language-server/Tree-sitter and local-index patterns, plus useful PR #1 indexing evidence after exact audit |
| `DISPOSITIONS` | `REFERENCE`, `PACKAGE`, or bounded `PORT` only after component/path/version/rights/security admission; reject mandatory cloud index/vector service |
| `TRUST` | Indexed source, comments, history and external objects are untrusted data; provenance/freshness/disclosure/admission policy is trusted |
| `AUTHORITY` | Fehrest retrieves and compiles; it cannot authorize, accept, mutate source, lower rigor or turn memory into truth |
| `DATA` | Local project and explicitly authorized cross-repository scopes; classification, source lineage, freshness, omission and deletion propagation retained |
| `NETWORK` | `LOCAL_ONLY`; no mandatory embeddings, hosted search, or connector contact; future egress requires explicit capability |
| `PLATFORM` | Windows filesystem and Git facts with explicit language-adapter support/limits; generated/binary/large repositories handled honestly |
| `FAILURE` | Stale, partial, unsupported, ambiguous, deleted or unavailable context is explicit and propagates to consumers |
| `NEGATIVE_TESTS` | Stale/superseded ADR, renamed symbol, unavailable dependency, generated/binary file, huge repo, injection in indexed text, provenance mismatch, source deletion/ACL change |
| `ACCEPTANCE` | Deterministic capsule digest, source links, freshness and coverage/omission ledger; rebuildable index; no context claim without provenance |
| `BENCHMARKS` | Index/full and incremental latency, query latency, memory/disk, retrieval recall/precision, freshness and C0–C5 context preparation cost |
| `NON_GOALS` | Semantic/acceptance authority, autonomous memory, universal languages, organization brain, Byan learning |
| `DEFERRED` | Broad cross-project/organization knowledge, optional semantic retrieval, connector fleet and advanced temporal reasoning |
| `EXPECTED_PATHS` | `crates/fehrest/**`, `crates/context/**`, `crates/index/**`, `crates/git/**`, `tests/fehrest/**` |
| `MIGRATION` | Versioned rebuildable index/provenance schemas; immutable source/evidence identities remain referenced; no silent re-admission |
| `RECOVERY` | Rebuild projections from sources and ledger; quarantine corrupt state; preserve immutable evidence and admission history |
| `EXIT` | Required local surfaces resolve with provenance/freshness/coverage, missing context remains explicit, and method/security/performance gates pass |
| `FOUNDER_AUTHORIZATION_REQUIRED` | `YES`—S4 authorization and ratified Maemar/Fehrest ownership relationship |

### 29.7 S5 — Spec Kit Mechanics, AGILLE, Plan Qualification, and Ponytail Sufficiency Gate

| Field | Reconciled plan |
|---|---|
| `PURPOSE` | Internalize typed specification, acceptance, risk, plan qualification and sufficiency mechanics as product capability |
| `USER_VALUE` | Work begins from clarified intent, testable acceptance, qualified plans and the smallest safe sufficient solution |
| `ARCHITECTURE_DELTA` | Adds Mission/spec/clarification/plan/task/checklist records, acceptance criteria/policy, risk profile, plan qualification and Ponytail sufficiency evidence |
| `OWNER` | AGILLE owns specification/acceptance/risk/qualification; Work owns human-governed goal aggregation; Mission Runtime owns execution lifecycle |
| `DEPENDENCIES` | S4 governed context; P0 vocabulary/ownership; external Spec Kit and Ponytail already govern the build method before S1 |
| `DONORS` | Exact pinned Spec Kit and Ponytail sources after component admission; Kiro/product planning behavior only as reference oracle |
| `DISPOSITIONS` | Port mechanics into typed AGILLE contracts; Markdown is evidence/input, never authority; port Ponytail questions/protected concerns; proprietary products reference only |
| `TRUST` | External text/artifacts and worker plans are untrusted inputs; admitted typed AGILLE records and authorized decisions carry product authority |
| `AUTHORITY` | Authorized human/role owns acceptance and any rigor reduction; model/worker/tool cannot accept, lower risk or waive protected concern |
| `DATA` | Local specification/planning artifacts with provenance, version/supersession and classification |
| `NETWORK` | `LOCAL_ONLY` by default; controlled egress only under explicit Nawat policy and disclosure record |
| `PLATFORM` | Platform-neutral contracts; Windows implementation/runtime evidence for Alpha; accessible/RTL UI for product surfaces |
| `FAILURE` | Ambiguous/contradictory intent, missing acceptance, stale plan, unqualified task or failed sufficiency remains blocked/incomplete |
| `NEGATIVE_TESTS` | Missing criterion, contradictory spec, untraceable task, worker lowers risk, Ponytail removes security/recovery/accessibility/evidence/authority, stale Markdown overrides canonical record |
| `ACCEPTANCE` | End-to-end objective→criterion→plan→task→test/evidence traceability; gaps explicit; FULL sufficiency answers; protected concerns retained |
| `BENCHMARKS` | Clarification/human burden, criterion coverage/quality, plan-defect/rework rate, task traceability, false qualification and cycle time |
| `NON_GOALS` | External Spec Kit as authority, automatic founder acceptance, dynamic workforce optimizer, generalized product-design suite |
| `DEFERRED` | Rich collaborative specification and adaptive risk/staffing beyond Alpha |
| `EXPECTED_PATHS` | `crates/agille/**`, `crates/specification/**`, `crates/qualification/**`, `crates/ponytail/**`, `tests/agille/**` |
| `MIGRATION` | External artifact mechanics map into versioned typed objects with provenance; earlier artifacts preserved and explicitly superseded |
| `RECOVERY` | Supersede plan/spec epistemically; never rewrite accepted history; requalify dependent tasks after material change |
| `EXIT` | A qualified Mission yields authorized tasks with traceable acceptance/risk/sufficiency and all method/negative/accessibility gates pass |
| `FOUNDER_AUTHORIZATION_REQUIRED` | `YES`—S5 authorization and final vocabulary/ownership ratification |

### 29.8 S6 — UWC, Mirefa Minimum, and Edara Minimum

| Field | Reconciled plan |
|---|---|
| `PURPOSE` | Execute one qualified worker route in one isolated, durable Attempt with a minimal governed ContextCapsule and bounded authority |
| `USER_VALUE` | Delegated work is visible, attributable, cancellable, reproducible and unable to expand its own scope |
| `ARCHITECTURE_DELTA` | Adds Universal Worker Contract, adapter conformance, native `Attempt`/worktree binding, Mirefa qualification/context transfer, deterministic Edara assignment and route/fallback lineage; an `Attempt` references immutable S3 `CommandRun`/`ProcessTreeRecord` execution records rather than reinterpreting or backfilling them |
| `OWNER` | Mission Runtime owns Attempts/checkpoints; UWC owns adapter contract; Mirefa qualifies routes/context; Edara assigns; Nawat grants effects |
| `DEPENDENCIES` | Qualified S3 containment for untrusted local worker, S4 context, S5 qualified plan, component admission, founder admissions decision |
| `DONORS` | delegate-skills schema/tests, Beads and agent/workforce systems as references, petgraph candidate for graph mechanics |
| `DISPOSITIONS` | delegate-skills schema/test donor only; petgraph package candidate after exact qualification; other frameworks reference/benchmark; no external workflow-server authority |
| `TRUST` | Every worker/model/adapter/harness/output is untrusted; outer launcher, policy/effect chokepoint and minimal state/evidence are trusted |
| `AUTHORITY` | Worker proposes/requests; Edara assigns; Mission Runtime records; Nawat grants/revalidates; worker cannot delegate or expand itself unless explicitly authorized |
| `DATA` | Minimum ContextCapsule, exact write/read scope, classification, provenance, secrets by lease reference, checkpoint/output/evidence refs |
| `NETWORK` | `LOCAL_ONLY` or named `CONTROLLED_EGRESS` route; no silent provider/model/harness fallback |
| `PLATFORM` | Windows containment profile required for untrusted local workers; no worktree-as-security claim |
| `FAILURE` | Timeout, crash, revocation, orphan, fallback, invalid output, overlapping effects and uncertain external effect remain durable explicit states |
| `NEGATIVE_TESTS` | Child self-delegation, grant expansion, overlapping writes, hidden fallback, context leak, unknown independence, orphan, replayed effect, credential possession treated as authority |
| `ACCEPTANCE` | One adapter passes UWC conformance; one isolated Attempt has exact lineage, caps/budget/context, cancellation/revocation/recovery and no authority expansion |
| `BENCHMARKS` | Startup/handshake, task outcome, context duplication, token/model/tool/VM costs, intervention, retries, coordination and topology overhead |
| `NON_GOALS` | Swarms, generalized workforce, adaptive optimizer, broad parallelism, native review, trusted worker completion |
| `DEFERRED` | Dynamic Edara optimizer, rich team topology, remote/cross-machine execution and multiworker economics |
| `EXPECTED_PATHS` | `crates/uwc/**`, `crates/mirefa/**`, `crates/edara/**`, `crates/mission_runtime/**`, `crates/adapters/**` |
| `MIGRATION` | Introduces durable Attempt/assignment/route/checkpoint/effect lineage; adapter versions explicit and replaceable |
| `RECOVERY` | Resume exact safe checkpoint or start a new authorized Attempt; reconcile leases/orphans/effects; never mutate prior provenance |
| `EXIT` | Single-worker topology passes conformance, containment, least-authority, cancellation, replay, recovery and economics gates |
| `FOUNDER_AUTHORIZATION_REQUIRED` | `YES`—S6 authorization, component admissions, and B-WIN-001 resolution for untrusted local worker |

### 29.9 S7 — Native Review and Assurance

| Field | Reconciled plan |
|---|---|
| `PURPOSE` | Deliver the first full WePLD-native independent, evidence-grounded review pipeline |
| `USER_VALUE` | A change receives understandable findings, immutable coverage/gaps, preserved dissent and acceptance grounding rather than a generic clean score |
| `ARCHITECTURE_DELTA` | Adds ReviewTarget/Plan/ProducerRun/Finding/Coverage/Outcome pipeline, governed rules, deterministic and AI producers, Fehrest context, risk routing, role-relative independence, validation/fusion and projections |
| `OWNER` | Logical Assurance owns review lifecycle; Fehrest supplies governed context; AGILLE supplies criteria/risk; Edara routes; minimal TCB admits/records only |
| `DEPENDENCIES` | S3-D evidence foundation, S4 context, S5 acceptance/risk and S6 qualified worker route |
| `DONORS` | open-code-review, reviewdog, pr-agent, OpenReview, MonkeyCode, deterministic tools; Cubic is actual external build reviewer and benchmark comparator |
| `DISPOSITIONS` | Apply exact ledger: OpenReview rights unknown/legal review; reviewdog derivation legal review; MonkeyCode reference/benchmark/negative oracle with unaudited OhMyAgent; no project auto-admitted |
| `TRUST` | All producer/model/parser findings and summaries are untrusted evidence; validators can also fail; trusted path validates envelopes, immutable evidence and state transitions |
| `AUTHORITY` | `ReviewOutcome != CompletionDecision`; finding/coverage/score/Cubic result grants no write, merge, release, acceptance or completion authority |
| `DATA` | Minimum disclosure-safe ReviewContextCapsule; exact target/rules/criteria/context/producer lineage; corpus kept separate from operational memory |
| `NETWORK` | `LOCAL_ONLY` and `CONTROLLED_EGRESS` are separate operational/experimental strata; every fallback and disclosure recorded |
| `PLATFORM` | Windows runtime claim with producer/platform limitations in coverage; deterministic local route always available for its admitted scope |
| `FAILURE` | Timeout, malformed output, missing context/tool, disagreement, invalid location, incomplete coverage or insufficient independence yields incomplete/blocked, never clean |
| `NEGATIVE_TESTS` | Prompt injection, secrets, self-review, shared route falsely independent, silent fallback, partial/oversized change, duplicate/conflict, stale context, false no-findings, producer/evaluator fail-open |
| `ACCEPTANCE` | Five target classes use one semantic pipeline; criterion/surface coverage and gaps immutable; roles independently qualified; findings normalized/evidenced; zero verdict/completion conflation |
| `BENCHMARKS` | D0/A/B/C/D; Cubic, WePLD-native and combined; `M-01..M-20`; `CTX-C0..CTX-C5` context; `CORPUS-C0..CORPUS-C4`; local/egress strata and full statistics |
| `NON_GOALS` | Controlled repair, Trusted Completion, generalized Runtime Verifier, automatic Cubic retirement, universal languages/tools |
| `DEFERRED` | Rich ReviewTour UX/projections, adaptive reviewer topology and generalized runtime verification |
| `EXPECTED_PATHS` | `crates/assurance/**`, `crates/review/**`, `crates/review_rules/**`, `crates/review_context/**`, `tests/review/**` |
| `MIGRATION` | S3-D envelopes evolve versionedly; immutable earlier coverage/run evidence preserved; projection schemas rebuildable |
| `RECOVERY` | Re-run producers against pinned target/plan/context; preserve prior runs/conflicts; no missing run fabricated or overwritten |
| `EXIT` | Native pipeline meets pre-registered safety floors/non-inferiority/budgets, records every limitation and passes method/authority/adversarial/accessibility gates |
| `FOUNDER_AUTHORIZATION_REQUIRED` | `YES`—S7 implementation and external-route/data-egress authorizations |

### 29.10 S8 — Controlled Repair, Bounded Fallback/Reassignment, and Trusted Completion

| Field | Reconciled plan |
|---|---|
| `PURPOSE` | Repair validated findings under separate authority, re-review independently, and decide completion only from admissible evidence and authority |
| `USER_VALUE` | Fixes are bounded, visible, recoverable and cannot self-approve; unresolved risk stays visible |
| `ARCHITECTURE_DELTA` | Adds RepairProposal, separate repair Attempt/write set, fallback/reassignment controls, re-review convergence, bounded own-surface VerificationRun and authorized CompletionDecision/receipt |
| `OWNER` | Mission Runtime owns repair Attempts; Nawat owns effects; Edara owns bounded assignment; Assurance owns re-review; Trusted Completion path owns decisions/receipts |
| `DEPENDENCIES` | S7 full review, acceptance policy, capability/effect receipts, founder Runtime Verifier scope decision |
| `DONORS` | PR #1 repair/worktree evidence and proprietary/OSS repair systems as behavior/negative oracles only after exact assessment |
| `DISPOSITIONS` | Port only bounded audited mechanics; reject direct reviewer writes, auto-approval, environment-success-as-completion and silent fallback |
| `TRUST` | Repairer, fallback worker, model and verifier are untrusted; effect chokepoint, evidence admission and completion decision/receipt are trusted |
| `AUTHORITY` | Finding proposes; Nawat separately grants exact effects; repairer cannot re-review acceptance-critical work; authorized human/policy decides completion |
| `DATA` | Attempt/worktree/change scoped; exact findings/write set/context/effects/evidence; audit survives source/worktree rollback |
| `NETWORK` | Route and fallback profiles explicit; no silent provider/model/egress change; verifier network/secrets named and bounded |
| `PLATFORM` | Windows containment/worktree/filesystem/process and selected WePLD-owned runtime surfaces only for Alpha verifier scope |
| `FAILURE` | Scope overrun, conflict, fallback, verifier unavailable/wrong target, non-convergence, open blocker, uncertain effect and exhausted retry remain explicit |
| `NEGATIVE_TESTS` | Repair exceeds finding/scope, repairer re-reviews, overlapping writes, tests green but runtime fails, wrong endpoint, missing evidence, fallback changes independence, retry exhaustion self-accepts |
| `ACCEPTANCE` | Separate least-authority Attempt, independent re-review, exact effect receipts, no partial promotion, completion impossible from worker/ReviewOutcome/verifier alone |
| `BENCHMARKS` | Repair rounds/time, convergence/regressions, M03/M04, human burden, verifier yield/cost, fallback/reassignment overhead and residual-risk outcomes |
| `NON_GOALS` | Unattended merge/release, arbitrary autonomous repair, third-party production verification, broad computer control |
| `DEFERRED` | General Runtime Verifier, generalized browser/computer use and autonomous fleet repair |
| `EXPECTED_PATHS` | `crates/repair/**`, `crates/completion/**`, `crates/verification/**`, `crates/mission_runtime/**`, `tests/trusted_completion/**` |
| `MIGRATION` | Adds repair/verification/completion lineage without rewriting review/attempt/effect evidence; state transitions versioned |
| `RECOVERY` | Revert source/worktree state while retaining Attempts, findings, effects, observations and decisions; reconcile uncertain effects before retry |
| `EXIT` | Blocking findings resolved or explicitly accepted with authorized disclosed residual risk; fail-open/self-certification tests impossible; method gates pass |
| `FOUNDER_AUTHORIZATION_REQUIRED` | `YES`—S8 authorization and Runtime Verifier Alpha-scope decision |

### 29.11 S9 — Quality Passport, Recovery Time Machine, and ChangeUnit/Delivery Evidence

| Field | Reconciled plan |
|---|---|
| `PURPOSE` | Make accepted quality, delivery lineage and recovery independently auditable for one ChangeUnit |
| `USER_VALUE` | The user can prove what was reviewed/accepted/delivered and restore safely without erasing history |
| `ARCHITECTURE_DELTA` | Adds Quality Passport, recovery checkpoint/manifests, one ChangeUnit minimum, delivery evidence, stack-family references, epistemic supersession and exact check-reuse evidence |
| `OWNER` | Passport/Recovery/Delivery modules under Core contracts; ChangeStack canonical family; Work/Mission/Assurance remain their own owners |
| `DEPENDENCIES` | S8 accepted evidence/effect/completion chain; V1.5 ChangeStack invariants; admitted storage/graph/Git mechanics |
| `DONORS` | V1.5 canonical contracts; Git Town, spr, ghstack and archived gh-stack as behavior/source evidence |
| `DISPOSITIONS` | Preserve canonical concepts; external stack tools reference unless separately admitted; archived source historical only; no hosted stack state as truth |
| `TRUST` | Passport/manifest is digest/signature-verifiable evidence; forge comments/checks/tool objects are observations; recovery executor remains capability-bound |
| `AUTHORITY` | Passport/delivery evidence records decisions; it grants no merge/release/publish authority and cannot substitute for CompletionDecision |
| `DATA` | Local append-only/content-addressed evidence, artifact/checkpoint manifests, exact ChangeUnit/revision/dependency/reuse digests |
| `NETWORK` | Offline verification required; forge publication/read is separate controlled egress/effect with current authorization |
| `PLATFORM` | Windows recovery/crash/storage semantics; forge-independent portable core format |
| `FAILURE` | Missing artifact/receipt, digest mismatch, stale stack revision, invalid reuse, interrupted restore, partial checkpoint or incompatible schema blocks claim |
| `NEGATIVE_TESTS` | Upstack mutation, restack/conflict change, mismatched reuse field, source rollback, forged passport, missing receipt, interrupted recovery, stale grant, forge unavailable |
| `ACCEPTANCE` | Complete offline-verifiable passport; independent restoration; reuse invalidates on any relevant mismatch; one ChangeUnit evidence path without premature stack UX |
| `BENCHMARKS` | Recovery time/success, passport verification latency/evidence size, reuse correctness, avoided reruns, storage overhead and failure recovery |
| `NON_GOALS` | Full ChangeStack UX, multi-unit stack optimizer, release automation and hosted forge truth |
| `DEFERRED` | Stacked-change authoring/restacking/delivery UX and advanced recovery visualization Post-Alpha |
| `EXPECTED_PATHS` | `crates/passport/**`, `crates/recovery/**`, `crates/changeunit/**`, `crates/delivery_evidence/**`, `tests/recovery/**` |
| `MIGRATION` | Versioned passport/recovery schemas; explicit supersession; immutable evidence/history never deleted or rewritten |
| `RECOVERY` | Restore source and runtime state from verified checkpoint; preserve append-only audit/evidence and reconcile external effects separately |
| `EXIT` | Passport/recovery verify independently, reuse cannot cross mismatch, crash/corruption tests pass, and method/authority gates pass |
| `FOUNDER_AUTHORIZATION_REQUIRED` | `YES`—S9 implementation authorization and any external delivery/forge effects separately authorized |

### 29.12 S10 — Fehrest Expansion and Byan Outcome/Benchmark Analytics Candidate

| Field | Reconciled plan |
|---|---|
| `PURPOSE` | Expand governed project knowledge and evaluate validated outcome/benchmark learning candidates without silent operational mutation |
| `USER_VALUE` | Evidence-based trends and improvement candidates are visible, reproducible and reversible without exporting or rewriting policy automatically |
| `ARCHITECTURE_DELTA` | Adds Fehrest expansion, Byan outcome ledger, validated metric ingestion, causal lineage, candidate insight/learning record and governed admission path |
| `OWNER` | Fehrest owns governed knowledge; Byan owns advisory analytics/candidates; Assurance owns source evidence; governance/AGILLE owns any admission/policy decision |
| `DEPENDENCIES` | S9 and validated S3-D/S7/S8/S9 evidence; corpus/benchmark protocols; retention/deletion/classification and Maemar decision |
| `DONORS` | Validated WePLD benchmark/outcome history and qualified analytics components/patterns only |
| `DISPOSITIONS` | Ingest only admitted validated evidence; no metric/corpus/vendor/donor/feedback becomes memory, rule or policy directly |
| `TRUST` | Analytics, correlations and generated hypotheses are advisory/untrusted; provenance, uncertainty, confounding and contamination are explicit |
| `AUTHORITY` | Byan emits candidates only; authorized governance admits changes; no auto-training, rule rewrite, rigor reduction or completion authority |
| `DATA` | Local benchmark/outcome evidence with rights/provenance/real-synthetic/annotation/contamination/deletion state; minimized derived snapshots |
| `NETWORK` | Zero metrics/data egress by default; controlled export/provider use requires explicit scoped capability and disclosure record |
| `PLATFORM` | Local Windows analytics with no cloud dependency; portable evidence formats and bounded resource use |
| `FAILURE` | Confounding, contamination, missing lineage, deletion mismatch, drift, underpower or irreproducibility yields insufficient evidence, not recommendation |
| `NEGATIVE_TESTS` | Feedback silently changes policy, corpus defect enters rule/context, metrics egress, causal claim lacks lineage, deleted/held data mishandled, candidate gains authority |
| `ACCEPTANCE` | Validated-only ingestion, candidate/admission separation, epistemic supersession, reproducible analyses and explicit limitations; no silent learning path |
| `BENCHMARKS` | D0/A/B/C/D; Cubic/native/combined; `M-01..M-20`; `CTX-C0..CTX-C5`; `CORPUS-C0..CORPUS-C4`; longitudinal incidents and Pareto decisions |
| `NON_GOALS` | Autonomous policy/model change, organization-wide brain, self-training, corpus-as-memory or adaptive Edara optimizer |
| `DEFERRED` | Cross-project/tenant learning, adaptive staffing/routing optimizer and broad organization analytics |
| `EXPECTED_PATHS` | `crates/byan/**`, `crates/fehrest/analytics/**`, `benchmarks/review/**`, `crates/governance/admission/**`, `tests/byan/**` |
| `MIGRATION` | Validated source evidence references immutable; analytics projections rebuildable; candidates versioned/revocable/superseded, never silently edited |
| `RECOVERY` | Rebuild projections from validated ledger; revoke/supersede candidate without deleting evidence; honor retention/deletion/hold rules |
| `EXIT` | No silent learning/egress/authority path; benchmark decisions meet pre-registered safety/statistical/economic rules and all method gates pass |
| `FOUNDER_AUTHORIZATION_REQUIRED` | `YES`—S10 implementation and any analytics data admission/egress authorization |

---

## 30. Shared Slice Gates and Evidence Packet

The external development method is used to build WePLD now and remains distinct from the native capabilities internalized in S5 and S7.

### 30.1 Gate sequence for every code change, including S3-D

| Gate | Required evidence |
|---|---|
| `G0 AUTHORIZATION` | Exact authorized slice, principal, repository/ref/write scope, permitted effects, budget and expiry; no authority inferred from this report |
| `G1 SPEC_KIT` | Use constitution → specify → clarify → plan → checklist → analyze → tasks → implement as applicable; preserve traceability; record exact release/tag/commit where applicable plus workflow/template digest, configuration and provenance; Spec Kit artifact is not canonical authority |
| `G2 PONYTAIL_FULL` | Record `PONYTAIL_MODE=FULL`, exact release/version/commit where applicable and ruleset/skill/configuration digest; test existence, duplication, native/stdlib/admitted-component options, abstractions, privileges, workers/services and deployment; never minimize away security, validation, correctness, recovery, evidence, accessibility or authority |
| `G3 ACQUISITION_RIGHTS` | Resolve each external component by exact path/version/blob/provenance/rights/disposition/dependencies/tests/prohibited imports; inspection/benchmark use is not admission |
| `G4 BUILDER_CONTROLS` | Build only within authorized tasks/write set; formatting, compilation, unit/integration/property/security/static/accessibility/platform checks use exact manifests and fail cleanly |
| `G5 CUBIC_PREFLIGHT` | When egress is allowed, record Cubic CLI/client version, review configuration/profile, observable service/policy snapshot where applicable, egress/retention/disclosure qualification and exact target/revision; review the exact local change, validate findings, repair under authority, rerun deterministic checks, and re-review; otherwise record exact `NOT_RUN_*` state. Exceptional acceptance without the normally required Cubic route requires an explicit waiver by the same authorized acceptance authority that may decide G9, an independently qualified substitute review route and recorded residual limitation |
| `G6 PR_REVIEW` | Only after separately authorized push/PR creation: Cubic PR review where permitted, repair, deterministic rechecks and re-review; PR/CI status is evidence only |
| `G7 RISK_INDEPENDENCE` | Add qualified independent/adversarial routes where risk requires; every relation in §10 recorded; extra workers require positive marginal accepted-outcome value net of coordination cost |
| `G8 RECONCILIATION` | Architecture/evidence review against canon, live repository truth, slice scope, source ledger, benchmark/negative evidence, data policy and unresolved limitations |
| `G9 ACCEPTANCE` | Only the founder or separately authorized completion authority accepts the slice; append decision/evidence receipt; tool/worker cannot self-accept |

### 30.2 Cubic rules

```text
Cubic clean        != CompletionDecision
Cubic approval     != founder acceptance
Cubic finding      != write authority
Cubic unavailable  != PASS
```

If source/context egress is disallowed:

```text
CUBIC_STATUS = NOT_RUN_DATA_EGRESS_DENIED
```

The status and coverage limitation are preserved. Other explicit statuses include `NOT_RUN_UNAVAILABLE`, `NOT_RUN_OUT_OF_SCOPE`, and `FAILED`; none is pass. Native S7 Assurance does not silently remove Cubic from the build workflow. Retirement requires pre-registered evidence that `WEPLD_NATIVE` is non-inferior or superior under accepted safety/quality floors, cost/latency budgets, platform and data-policy strata.

### 30.3 Per-slice build evidence bundle

- authorization and immutable target/base/head identities;
- Spec Kit artifact references, exact tool/workflow/template provenance/configuration digests and requirement/task/test/evidence traceability;
- Ponytail FULL answers, exact ruleset/skill/configuration provenance digest, protected concerns and rejected alternatives;
- component/path/version/rights/security/admission records and SBOM;
- deterministic check manifests, exact tool/config/environment digests and raw evidence;
- Cubic client/configuration/profile/service-policy snapshot evidence where observable, egress/retention/disclosure qualification, exact target/revision, preflight/PR evidence or exact `NOT_RUN_*` state; any exceptional waiver, independently qualified substitute route and residual limitation;
- findings, validation, repair, effects and re-review lineage;
- role-relative independence graph including every `UNKNOWN`;
- benchmark/acceptance results, floors/budgets and limitations;
- architecture/evidence reconciliation and authorized decision/receipt.

No CI result, review approval, green check, benchmark score, mergeability state or worker statement independently authorizes completion.

---

## 31. Review Benchmark Laboratory

The laboratory tests whether each architecture layer creates decision-relevant value under its cost, risk and disclosure constraints. It is not a leaderboard exercise and cannot ratify architecture from vendor-reported scores.

### 31.1 Corrected comparison ladder

| Arm | Treatment |
|---|---|
| `D0` | Deterministic admitted tools only; no AI/learned review output |
| `A` | Raw AI reviewer with target/diff mechanics only |
| `B` | A plus governed versioned `ReviewRule` set |
| `C` | B plus Fehrest context and AGILLE intent/acceptance/risk truth |
| `D` | C plus full WePLD Assurance topology: planning/routing, role-relative independence, validation/fusion/conflict, bounded verification and lifecycle controls |

`LOCAL_ONLY` and `CONTROLLED_EGRESS` are experimental strata, not a twenty-first metric. External-review comparisons are:

```text
CUBIC
WEPLD_NATIVE
CUBIC + WEPLD_NATIVE
```

Hold target, ground truth, acceptance obligations and applicable budgets/model conditions constant where scientifically possible. If a proprietary service prevents exact control, record the mismatch and restrict the claim; do not manufacture equivalence.

Universal monotonic improvement from D0→A→B→C→D is neither required nor assumed. Added context or topology may dilute signal, raise leakage/cost, or harm quality.

### 31.2 Exactly twenty metric families

| ID | Metric family | Required expression |
|---|---|---|
| `M-01` | Severity-weighted precision | Weighted true findings / weighted reported findings |
| `M-02` | Severity-weighted recall | Weighted found defects / weighted ground-truth defects |
| `M-03` | Escaped defects | Missed ground-truth defects by severity, with HIGH/CRITICAL separate |
| `M-04` | False-success rate | Satisfied/clean outcomes while a ground-truth HIGH/CRITICAL defect exists; headline safety guardrail |
| `M-05` | False-positive / human-noise burden | Human-rejected findings per accepted finding and review |
| `M-06` | Acceptance-criteria coverage | Criteria evaluated with admissible evidence / criteria defined |
| `M-07` | Architecture-issue detection | Ground-truth architecture violations found |
| `M-08` | Security-issue detection | Ground-truth security defects found |
| `M-09` | Review-coverage completeness | In-scope files, surfaces, rules, requirements and risks evaluated, with explicit gaps |
| `M-10` | Location accuracy | Findings anchored to correct revision/file/symbol/context window |
| `M-11` | Finding reproducibility and evidence quality | Stability over pinned repeated runs plus sufficient provenance/evidence fraction |
| `M-12` | Reviewer independence | Required role-relative relationships actually satisfied; `UNKNOWN` fails |
| `M-13` | Repair rounds | Attempts, regressions and elapsed convergence by severity |
| `M-14` | Runtime-verification yield | Valid defects found by bounded runtime evidence that static review missed |
| `M-15` | Post-merge reverts / incidents | Longitudinal escaped-defect outcome and severity |
| `M-16` | Human intervention time | Active human attention per review and accepted outcome |
| `M-17` | Latency | Wall time to evidence, outcome, repair and acceptance, reported separately |
| `M-18` | Token / context use | Input/output tokens, capsule size, expansions, cache/retrieval use and omissions |
| `M-19` | Monetary cost | Model/provider/service/VM/tool cost per review and accepted finding |
| `M-20` | Deterministic-tool cost | CPU, memory, I/O and elapsed cost of deterministic evidence production |

The full vector is reported. No weighted scalar may hide an `M-03` or `M-04` regression.

### 31.3 Pre-registered decision and statistical rules

Before a gate run, record primary accepted-outcome measures, safety guardrails, quality floors, cost/latency/disclosure budgets, non-inferiority margins, allowed trade-offs, hypotheses, strata/context, sample/power and stopping rules.

1. A safety-guardrail breach cannot be offset by mean F1, latency or cost.
2. An added layer is accepted only if its pre-registered superiority or non-inferiority condition holds while all safety floors/budgets hold.
3. Report the M-01–M-20 vector and Pareto frontier; do not optimize one scalar.
4. Use paired repeated runs on the same targets, pinned prompts/tools/configuration, seed/stochasticity controls, confidence intervals and effect sizes.
5. Correct multiplicity when testing many arms, contexts or defect classes; distinguish confirmatory from exploratory analysis.
6. Separate sealed/frozen regression results from longitudinal live results.
7. Missing, blocked, timed-out, malformed, denied-egress and unavailable-route runs are missing/blocked evidence, never success.
8. Preserve raw manifests/results so reproduction is possible and limitations are inspectable.
9. Report heterogeneous effects by severity, defect type, language, repository, change size, risk profile and local/egress stratum; no universal aggregate claim.
10. Record planning/decomposition, producer/model/tool/VM, duplicated work, merge/synthesis/evaluation/retry/waste and human coordination cost for workforce comparisons.

### 31.4 Context-economics ablations

| Regime | Contents |
|---|---|
| `CTX-C0` | No context beyond target/diff mechanics |
| `CTX-C1` | Minimal intent and acceptance criteria |
| `CTX-C2` | Targeted local project context |
| `CTX-C3` | Targeted cross-repository context |
| `CTX-C4` | Relevant history and bounded runtime evidence |
| `CTX-C5` | Deliberately overstuffed context |

Each regime records capsule/source digests, provenance/freshness/classification, retrieval misses, omissions, tokens, latency, cost, disclosure risk, quality, false success, architecture/security detection, coverage and human burden. CTX-C5 is a harm/dilution probe, not an assumed optimum.

### 31.5 Staged corpus protocol

| Stage | Purpose and gate |
|---|---|
| `CORPUS-C0` | Tiny mechanism fixtures proving manifests, labels, replay, coverage and failure semantics |
| `CORPUS-C1` | Annotation pilot validating taxonomy, independent annotation, adjudication, severity calibration, rights workflow and cost |
| `CORPUS-C2` | Power-sized stratified gate corpus; size follows primary measures/non-inferiority margins, stratified by severity/class/language/repository/change size and including no-defect controls |
| `CORPUS-C3` | Sealed adversarial/rare-event holdout: prompt injection, architecture/security defects, runtime divergence, huge/generated/binary changes and rare HIGH/CRITICAL cases |
| `CORPUS-C4` | Longitudinal live set of accepted outcomes, escaped defects, reverts, incidents and drift |

Every item records rights, provenance, repository/revision, exact defect/fix or no-defect basis, real/synthetic status, independent annotations, adjudication, severity calibration, contamination and disclosure class. The sealed set must not enter Fehrest, ReviewRules, prompts, memory or tuning. Before S10, corpus/runner/metrics are evaluation infrastructure and evidence—not Byan knowledge.

---

## 32. Adversarial, Failure, and Negative-Test Matrix

These are architecture acceptance cases, not an implementation authorization or a claim that they have run.

### 32.1 Review, repair, completion, and evidence

| ID | Adversarial case | Required result |
|---|---|---|
| `R-01` | Producer timeout/unavailable | Run records timeout/unavailable; immutable coverage gap; outcome incomplete |
| `R-02` | Malformed structured output | No finding/pass synthesized from unparseable output; failure explicit |
| `R-03` | Evaluator/parser failure or exhausted retry | Never default to acceptable quality; incomplete/failed/manual review |
| `R-04` | Large change exceeds budget | Every unreviewed file/surface enumerated; no silent truncation |
| `R-05` | Finding location drifts after rebase/rename | Re-anchor with evidence or mark stale/superseded/unresolvable |
| `R-06` | Duplicate or conflicting findings | Fuse duplicates with provenance; preserve genuine disagreement and routes |
| `R-07` | False-positive feedback | Learning candidate only; no silent rule/threshold/route/exclusion change |
| `R-08` | Builder/reviewer same principal/Attempt where independence required | Requirement fails; self-review remains labelled advisory only |
| `R-09` | Required relationship shared or `UNKNOWN` | Independence fails; unknown never counts as independent |
| `R-10` | Silent provider/model/harness fallback | Reject; persist fallback, disclosure and recompute independence/profile |
| `R-11` | Acceptance criteria missing/contradictory | Record gap; acceptance-critical outcome cannot be satisfied |
| `R-12` | ADR/context stale or superseded | Mark lineage; invalidate/re-evaluate dependent context/findings |
| `R-13` | Cross-repository source unavailable/stale/ACL-changed | Coverage names surface and freshness; never assume clean |
| `R-14` | Capsule digest/source/omission mismatch | Review invalid/incomplete until reconciled; no hidden expansion |
| `R-15` | Generated/binary/unsupported file mishandled | Explicit exclusion and limitation; unsupported producer cannot claim coverage |
| `R-16` | ReviewRule glob/priority conflict | Deterministic versioned precedence or blocked rule set with record |
| `R-17` | Issue/comment/source contains injection or secrets | Treat as untrusted, redact/contain and report; cannot override instructions/scope |
| `R-18` | Repair exceeds finding/write/capability scope | Nawat denies and records; finding remains open |
| `R-19` | Reviewer/producer attempts mutation or policy change | Deny and record security event; no inferred repair authority |
| `R-20` | Verifier cannot reach exact environment | Verification blocked with limitations; never pass |
| `R-21` | Verifier exercises wrong revision/path/endpoint | Observation not counted toward target coverage |
| `R-22` | Static tests green but real selected path fails | Runtime divergence visible; completion/profile claim blocked as configured |
| `R-23` | Verification artifact missing/digest mismatch | Unsupported observation; run incomplete |
| `R-24` | “No findings” with incomplete coverage | Projection leads with gap; cannot present clean/pass |
| `R-25` | Upstack/restack mutation invalidates review | New evaluation identity; re-anchor/re-run/supersede explicitly |
| `R-26` | Check-reuse tuple differs in any relevant field | Re-run and preserve field-by-field mismatch evidence |
| `R-27` | Scan interrupted/resumed | Equivalent pinned result or disclosed divergence/partial state |
| `R-28` | AI egress denied | Local deterministic evidence continues; AI route blocked; no cloud fallback/pass |
| `R-29` | Secret reaches reviewer input | Deny route before transfer, redact and record security event |
| `R-30` | ReviewOutcome converted to CompletionDecision | Type/architecture test fails; no conversion path exists |
| `R-31` | Source contains instruction to reviewer/tool | Instruction ignored as untrusted content; injection finding where applicable |
| `R-32` | Unadmitted/malicious ReviewRule | Rule inert; admission/evidence event records rejection |
| `R-33` | One local model cannot meet independence profile | Outcome blocked/incomplete, not silently downgraded |
| `R-34` | Worker/repository asks to lower risk/profile | Reject; only authorized role can reduce with recorded rationale/residual risk |
| `R-35` | Required deterministic tool missing | Profile remains unmet/incomplete; no auto-reduction to available tools |
| `R-36` | Tool/config/environment digest differs | Block or create new declared run; never silently treat equivalent |
| `R-37` | Repair Attempts overlap write sets | Reject/serialize/replan before execution; no race by optimism |
| `R-38` | Repairer assigned acceptance-critical re-review | Reject topology where independence required |
| `R-39` | Completion attempted with open blocking finding | Block |
| `R-40` | Completion with acceptance-critical unverified coverage | Block unless authorized policy explicitly permits disclosed residual-risk decision |
| `R-41` | Sealed corpus item enters rule/context/tuning | Detect contamination; invalidate affected runs/admission |
| `R-42` | Metrics/Byan subsystem attempts unauthorized egress | Deny and record security event |
| `R-43` | Ported component imports rejected/unreviewed upstream path | Build/acquisition gate fails |
| `R-44` | Source/worktree rollback erases evidence/audit | Test fails; immutable evidence survives operational rollback |
| `R-45` | Worker/harness returns normally after tool error | Completion proposal records failure/uncertainty; no no-exception⇒complete rule |
| `R-46` | Quality parser retries exhausted | Never substitute threshold-passing default score; failure/manual review |
| `R-47` | Browser/local session already authenticated | No extra read/write/disclose/publish authority; effect still denied absent lease |
| `R-48` | Scheduled/automatic workflow skips confirmation | Effect-time authorization and freshness still required; expired/revoked lease fails |

### 32.2 Development method, acquisition, and benchmark

| ID | Adversarial case | Required result |
|---|---|---|
| `MTH-01` | Code has no Spec Kit trace | Slice gate fails; artifact gains no authority |
| `MTH-02` | Spec Kit Markdown treated as canon | Reject; typed/governed WePLD record remains authority |
| `MTH-03` | Ponytail mode absent/reduced | Gate fails; `PONYTAIL_MODE=FULL` is required |
| `MTH-04` | Sufficiency removes security/correctness/recovery/evidence/accessibility/authority | Reject regardless of apparent simplicity |
| `MTH-05` | Added worker/service lacks net accepted-outcome value | Reject topology expansion or require evidence-gated experiment |
| `MTH-06` | Cubic receives code/context without egress grant | Deny before transfer and record policy event |
| `MTH-07` | Egress denial/unavailability shown as Cubic pass | Gate fails; exact `NOT_RUN_*` state required |
| `MTH-08` | Cubic finding/approval used as mutation/completion authority | Type/authority gate fails |
| `MTH-09` | S7 silently retires Cubic | Fail until pre-registered non-inferiority/superiority evidence and founder decision |
| `MTH-10` | External build method conflated with native product capability | Reconciliation fails; producer/authority/stage must be explicit |
| `ACQ-01` | Repository license badge treated as component admission | Fail; exact path/blob/dependency/security/NOTICE record required |
| `ACQ-02` | OpenReview README “MIT” treated as operative grant | Fail; remain `RIGHTS_UNKNOWN / LEGAL_REVIEW_REQUIRED` |
| `ACQ-03` | reviewdog code/schema/fixture translated/copied without artifact review | Fail acquisition/legal gate |
| `ACQ-04` | MonkeyCode AGPL code enters proprietary tree | Fail unless separately approved compliant rights strategy; negatives remain reference |
| `ACQ-05` | OhMyAgent reviewer behavior assumed from unavailable gitlink | Fail; internals/rights/tests remain unaudited/unknown |
| `ACQ-06` | Empty webhook secret accepts event | Fail closed; secret required or endpoint disabled |
| `ACQ-07` | PR URL/time window suppresses legitimate new-head event | Fail; bind delivery/event and immutable head identity |
| `ACQ-08` | Magic text suppresses bot loop | Fail; use authenticated principal/producer provenance |
| `ACQ-09` | Raw webhook/secrets logged or token injected ambiently | Fail; minimize/redact and use short-lived least-authority lease |
| `B-01` | D0 includes AI/learned output | Arm invalid |
| `B-02` | Arms change target/budget/ground truth without disclosure | Comparison invalid or explicitly stratified |
| `B-03` | Universal monotonicity required/claimed | Analysis invalid; use floors/margins/budgets/Pareto evidence |
| `B-04` | One stochastic run decides gate | Invalid; paired repeats and uncertainty required |
| `B-05` | Aggregate/F1 hides M-03 or M-04 regression | Reject decision; safety guardrail dominates |
| `B-06` | Local/egress encoded as M-21 | Schema fails; it is a stratum, not metric family |
| `B-07` | CTX-C5 assumed superior | Invalid; compare empirically to CTX-C0–C4 |
| `B-08` | Corpus count arbitrary/underpowered | CORPUS-C2 gate fails pending power analysis |
| `B-09` | Item lacks rights/provenance/independent annotation/adjudication | Exclude from gate corpus |
| `B-10` | Sealed holdout enters operational context/rules/tuning | Contamination invalidates affected results |
| `B-11` | Cubic/native conditions differ invisibly | Record mismatch; prohibit unsupported causal/superiority claim |
| `B-12` | Benchmark/inspection treated as source admission | Acquisition gate fails |
| `B-13` | Missing/blocked route imputed as clean zero-findings | Analysis fails; preserve missingness and reason |
| `B-14` | Multiple testing/p-hacking/stopping after favorable run | Confirmatory claim rejected; apply preregistration/correction |

### 32.3 Windows containment families

The S2/S3 suite includes all §21 dimensions and, at minimum:

- token privilege/group/integrity/elevation/impersonation escape;
- Job Object breakaway, nested jobs, detached descendants, grandchildren and kill/cancel/restart races;
- symlink/junction/reparse/TOCTOU, `.git`/protected path, volume/device/UNC, ADS, long path, reserved name, case/Unicode collision;
- IPv4/IPv6, TCP/UDP, DNS, loopback, proxy/VPN/local-subnet and WFP-control-process failure/lifecycle;
- environment/browser/SSH/Git/cloud credential enumeration and unauthorized provider use;
- inherited/duplicated handles, pipes/RPC/COM/window messages, clipboard, shared memory and ConPTY escape;
- process/memory/handle/disk/file/output/decompression/time bombs and bounded logging/backpressure;
- atomic startup, partial enforcement failure, orphan/stale state, crash, reboot, idempotent teardown/reconciliation;
- direct executable, `cmd.exe`, PowerShell, scripts/interpreters/build tools/installers and unusual quoting/encoding;
- performance and evidence integrity under allow, deny, overload and degraded enforcement.

No successful trusted-path-only test can be represented as hostile-worker containment evidence.

### 32.4 False-success meta-test

For every UI/API/report state named “clean,” “pass,” “satisfied,” “complete,” or “accepted,” inject at least one missing producer, unavailable context surface, unknown independence relation, denied Cubic route, corrupted evidence artifact, expired capability, or evaluator failure. Presentation must become incomplete, blocked, failed, limited, or an explicitly authorized residual-risk state. If it remains clean, the architecture contains a false-success defect.

---

## 33. Decision Records Required Before Implementation

This V2 removes ADRs whose only purpose was to ask the founder to re-ratify already canonical technical concepts. ChangeStack and Design/Accessibility do not need new existence votes. Contract counts, corpus size and exact source imports are technical/evidence gates, not architecture plebiscites.

The following compact set should be written only after the relevant founder decision and evidence exist:

| ID | Record | Scope |
|---|---|---|
| `ADR-P0-01` | Canonical vocabulary, aggregate ownership and Maemar placement | §5–§10 and founder decisions 1/4; includes logical-vs-deployable boundary |
| `ADR-P0-02` | Physical Trusted Core, authority/evidence/effect/completion chokepoints | Minimal TCB, untrusted producer/worker placement, fail-closed completion |
| `ADR-P0-03` | Assurance semantic contract and lifecycle boundary | Producer runs, immutable coverage/evidence, findings/conflicts, projections and `ReviewOutcome != CompletionDecision` |
| `ADR-P0-04` | Role-relative independence and context disclosure | §10 graph, evidence-source diversity, information-set/cache/memory and Nawat egress controls |
| `ADR-P0-05` | Windows execution profiles and qualification | §21 properties, atomic launch, fail-closed network and no-untrusted-worker fallback |
| `ADR-P0-06` | Bounded Runtime Verifier | Evidence-without-verdict, Alpha target/environment boundary, failure/replay semantics |
| `ADR-P0-07` | Benchmark/corpus decision protocol | D0/A/B/C/D, `M-01..M-20`, `CTX-C0..CTX-C5`, `CORPUS-C0..CORPUS-C4`, floors/budgets/statistics/Pareto and Cubic comparison |
| `ADR-P0-08` | Component acquisition and build-method controls | Per-component admission/exit, Spec Kit, Ponytail FULL, Cubic egress/non-authority and deprecation evidence |

Governance decisions are separate records, not ADRs:

| ID | Governance record |
|---|---|
| `GDR-P0-01` | Repository visibility, proprietary/IP/access and publication posture |
| `GDR-P0-02` | PR #11 replacement/supersession/cross-link/closure disposition |
| `GDR-P0-03` | PR #1 donor ledger/archive/supersession/cross-link/closure disposition |
| `GDR-P0-04` | ADR/history namespace and supersession manifest |
| `GDR-P0-05` | Corrected ten-slice roadmap, non-primary S3-D and authorization boundaries |

Each record states context, evidence, options, decision authority, decision, consequences, dissent/uncertainty, superseded records, migration/recovery, review date and falsifiers. Merely copying this report is not a decision record.

---

## 34. Repository, History, Migration, and Branch Strategy

### 34.1 Authority and preservation

The live `main` branch remains the source of current repository truth at SHA `993b2fb55af038091f365ad29d0740bdb1bd6c9e`. V1.5 and this report are planning artifacts outside the repository; neither silently mutates or replaces repository content. In a future authorized governance task, ratified successor artifacts must enter through the decided privacy/IP posture and ordinary protected review—not by rewriting history.

Historical documents/ADRs remain immutable evidence with explicit generation, source ref/blob, effective/superseded status and successor link. The recommended namespace is:

```text
docs/adr/current/<approved-id>.md
docs/adr/history/<generation>/<original-id>.md
docs/adr/history/MANIFEST.md
```

This is a recommendation subject to founder decision 8. It is not permission to move a file. IDs never imply chronological/canonical authority without the manifest.

### 34.2 PR and branch disposition

| Object | Live state | Future authorized disposition |
|---|---|---|
| `main` | Current public default branch at exact SHA above | Preserve history; no force-push or silent canonical substitution; successor enters after B-GOV-001 and governance approval |
| PR #11 / `docs/s0-b-product-architecture-foundation` | Open draft, unmerged, clean/mergeable; head `68cab399748c5c103b8f96380da69fdffca4d3fe` | Do not merge unchanged. Land/ratify replacement first, map every useful item to successor/rejection, preserve immutable ref/cross-links, then close superseded after founder approval |
| PR #1 / `feat/build-feature-engineering-memory` | Open draft, unmerged, dirty/non-mergeable; head `d5ef318468b6c35df3c14c1c5f72beb1191baf29` | Never wholesale merge. Complete path/concept donor ledger, preserve archival immutable ref if needed, cross-link destinations/rejections, then close superseded after founder approval |
| Other historical refs | Not dispositioned by this bounded Stage-3 task | Preserve until a separately authorized complete ref/citation audit; do not delete from partial evidence |

No branch, tag, PR, comment, review, commit, ruleset, visibility or repository setting is changed by this report.

### 34.3 Product/schema migration doctrine

- append versioned records; do not rewrite accepted evidence/history;
- distinguish reversible projections from authority-bearing records before migration;
- preflight compatibility, backup/checkpoint and rollback/recovery; crash-test partial migration;
- preserve source/provenance/decision/effect identities across replacements;
- make downgrade support explicit; never silently parse a newer envelope as older;
- external effects are reconciled/compensated separately from local source/state rollback;
- component replacement retains admission/version and evidence lineage and exercises the exit plan.

---

## 35. Alpha Non-Goals and Scope Guardrails

Unless separately founder-authorized with evidence, Alpha excludes:

- full ChangeStack authoring/restack/dependency/delivery UX beyond one S9 ChangeUnit evidence path;
- generalized Runtime Verifier, arbitrary production systems, broad browser/computer control and remote phone-initiated host effects;
- autonomous swarms, general dynamic Edara optimization, open-ended worker creation and cross-machine fleet orchestration;
- enterprise multi-tenant/team collaboration, SSO/admin controls, organization-wide knowledge and cross-tenant learning;
- broad nonsoftware object models and generalized workflow automation;
- self-training, feedback-to-policy auto-write, Byan operational authority and benchmark corpus as memory;
- unattended merge/release/publish/purchase/message, scheduled confirmation bypass, or credential-possession authority;
- hosted control plane or mandatory cloud index/reviewer as canonical truth;
- universal language/tool/provider/platform support or a containment claim broader than tested profiles;
- installer, auto-update, broad telemetry or public code publication before their specific governance/security gates;
- formal verification for every risk tier; CRITICAL formal/property controls remain evidence-gated and targeted;
- source acquisition by repository badge, wholesale harness adoption or dependency installation from this planning record.

These guardrails preserve a founder-usable vertical slice while keeping interfaces extensible and evidence honest.

---

## 36. Post-Alpha and Evidence-Gated Expansion

Post-Alpha candidates include full ChangeStack UX and multi-unit delivery; generalized/runtime-domain verifier profiles; broad browser/computer-use and external-system effects; enterprise collaboration/tenant administration; cross-project/organization Fehrest; nonsoftware Work objects; adaptive Edara/workforce optimization; richer ReviewTour and design/accessibility surfaces; formal CRITICAL profiles; remote execution; and cross-project Byan analytics.

Each candidate requires a new founder authorization, Ponytail FULL sufficiency record, component/rights/security evidence, threat/data/authority model, benchmark/operational evidence, migration/recovery/exit design, and explicit effect/acceptance ownership. “Deferred” means not authorized, not forgotten.

Cubic remains part of the development workflow until a pre-registered, independently reviewed comparison shows WePLD-native alone is non-inferior or superior for accepted safety/quality floors across relevant strata, stays within cost/latency/disclosure budgets, and retains adequate independent challenge. Deprecation is a founder/governance decision with an exit/fallback record; it is never inferred from reaching S7.

---

## 37. Founder / Governance Ratification Register

No former 24-question register is restored. The ten Stage-3 decision IDs remain immutable traceability records; they are not all current-answer questions. Spec Kit + Ponytail + Cubic is current direction, not an eleventh decision.

### 37.0 Current Founder Ratification Packages

```text
CURRENT_FOUNDER_RATIFICATION_PACKAGES = 6
```

The current founder ratification workflow groups the answerable decisions without deleting or renumbering their underlying IDs:

1. **`RAT-01 Architecture ownership`** — recommend `Fehrest.Maemar`; ratify reconciled vocabulary/aggregate boundaries. Maps `FD-P0-001` + `FD-P0-006`.
2. **`RAT-02 Repository/IP posture`** — proprietary/Private posture; owner/admin containment and historical-exposure review before code publication. Maps `FD-P0-012`.
3. **`RAT-03 Historical/PR governance`** — PR #11 replacement-first then close superseded; PR #1 donor ledger/archive if needed then close superseded; immutable history plus namespaced ADR/supersession manifest. Maps `FD-P0-004` + `FD-P0-005` + `FD-P0-016`.
4. **`RAT-04 Windows execution scope`** — authorize bounded Windows containment qualification; `NO_UNTRUSTED_LOCAL_WORKER` until an approved profile passes. Maps `FD-P0-011`.
5. **`RAT-05 Roadmap`** — ten primary S1–S10 slices plus non-primary S3-D Assurance Seed gate. Maps `FD-P0-017`.
6. **`RAT-06 Runtime Verifier Alpha scope`** — WePLD-owned desktop/Core/terminal/project/review surfaces only; generalized external production/browser/computer verification Post-Alpha. Maps `FD-P0-022`.

`FD-P0-013` is retained below for traceability but classified `FUTURE_EVIDENCE_GATED_APPROVAL`: it cannot be answered before the component-specific evidence exists and is therefore not a current founder ratification package.

### 37.1 `FD-P0-001` — Maemar ownership and name

**Decision:** choose top-level bounded context, named Fehrest domain, or explicit split. **Recommendation:** `Fehrest.Maemar` with a mandatory capability register, retaining declared/implemented/build/runtime/deployment/supply-chain/target architecture, semantic structure, ownership/trust, decisions, impact and drift. **Consequence:** resolves architecture-context ownership without service proliferation; required before S4/S7 contract exit.

### 37.2 `FD-P0-004` — PR #11 supersession and closure

**Decision:** authorize the §23 replacement-first/cross-link/archive/close-superseded path or choose another durable disposition. **Recommendation:** replacement first, then close as superseded; do not merge unchanged or leave a stale draft as the governance marker. No action in this task.

### 37.3 `FD-P0-005` — PR #1 donor, archive, and closure

**Decision:** authorize exact salvage ledger, immutable archival reference where needed, successor links and closure as superseded. **Recommendation:** do so after evidence extraction; never wholesale merge/rebase. No action in this task.

### 37.4 `FD-P0-006` — Final vocabulary and aggregate ownership

**Decision:** ratify or amend §5–§10 names, owners and no-duplicate-truth rules, including Work/AGILLE/Mission Runtime and Mirefa/Edara/Nawat/UWC. **Recommendation:** ratify the reconciled logical boundaries while leaving exact technical schemas to P0 evidence work.

### 37.5 `FD-P0-011` — Windows qualification or no-untrusted-worker Alpha

**Decision:** require a bounded profile to pass §21 before Alpha worker execution, or explicitly ship Alpha with no untrusted local worker. **Recommendation:** fail closed to no-untrusted-worker until the bounded profile has adversarial evidence; do not weaken the profile to preserve schedule.

### 37.6 `FD-P0-012` — Private/Public governance and IP posture

**Decision:** reconcile the currently public repository with adopted proprietary/Private posture, including visibility, access, fork/history/secret review, publication and future contribution policy. **Recommendation:** establish an owner/admin session and approved containment plan before any implementation/code publication; do not assume changing visibility retroactively removes public exposure.

### 37.7 `FD-P0-013` — Component-specific S1 and S3-D admissions

**Classification:** `FUTURE_EVIDENCE_GATED_APPROVAL`, not a current founder ratification package. Accept/reject each actual component only after the §27 record exists, including platform/IPC/storage/process and deterministic review candidates. **Recommendation:** grant no blanket donor approval; make a narrow record per component/path/version and preserve replacement/exit strategy.

### 37.8 `FD-P0-016` — ADR/history namespacing and supersession

**Decision:** approve a generation-aware namespace/manifest and treatment of colliding historical sequences. **Recommendation:** immutable historical trees plus current namespace and explicit successor links as in §34; never renumber/rewrite history silently.

### 37.9 `FD-P0-017` — Corrected roadmap and S3-D

**Decision:** ratify ten primary slices S1–S10, non-primary S3-D and the dependency/authorization gates in §§28–30. **Recommendation:** ratify; keep Byan at S10 and first full native Review/Assurance at S7.

### 37.10 `FD-P0-022` — Runtime Verifier Alpha scope

**Decision:** choose bounded WePLD-owned surfaces, no Alpha verifier, or a separately justified wider profile. **Recommendation:** bounded WePLD desktop/Core/terminal/project/review surfaces only; third-party production/general browser/computer-use verification Post-Alpha.

---

## 38. Current Scoped Blockers

```text
CURRENT_SCOPED_BLOCKERS_COUNT = 2
```

### 38.1 `B-GOV-001` — Public repository vs proprietary/Private posture

**Evidence:** `wepld/wepld` is live Public. **Blocks:** repository implementation/code publication and any action that assumes the proprietary/Private posture is already enforced. **Does not block:** this read-only reconciliation or preparation of P0 governance/evidence artifacts outside repositories. **Resolution authority:** founder/owner-admin governance decision, with historical-exposure and access review.

The currently connected read-only evidence session is `IamShehri` (ID `285091250`) with `admin=false`; owner object `wepld` is ID `304164736`. This did not block read-only verification, but future owner/admin-only mutation must establish and reverify the proper session.

### 38.2 `B-WIN-001` — Unqualified Windows containment for untrusted local workers

**Evidence:** useful primitives and source oracles exist, but no complete adversarial profile proves the §21 properties; known fail-open/gap cases remain. **Blocks:** untrusted local worker execution and any claim that trusted tooling is safe over untrusted project content without a profile qualified for that input class. **Does not block:** P0 planning, contracts, acquisition work, deterministic tooling over inputs covered by its disclosed qualified profile, or a no-untrusted-worker Alpha. **Resolution:** pass an approved bounded profile or ratify the no-untrusted-worker Alpha fallback.

Direct V1.5 inspection closed the former evidence blocker. V1.5 ChangeStack evidence closed the former lineage blocker. Contract refinement, corpus design and component admission are P0 tasks, not additional current scoped blockers.

---

## 39. Required Next Founder Action

The next action is a read-only/recorded founder ratification pass over the six current packages in §37.0, preserving all ten historical decision IDs for traceability. `FD-P0-013` remains a future evidence-gated approval. Priority remains `RAT-02` / `FD-P0-012` because repository posture blocks code publication and `RAT-04` / `FD-P0-011` because it controls untrusted-local-worker eligibility. The ratification should:

1. record answers/dissent/deferrals for `RAT-01` through `RAT-06` and exact authority while retaining their underlying decision IDs;
2. approve or amend P0-D1–D7, the ten slices and S3-D, without pre-answering `FD-P0-013`;
3. decide whether a subsequent task is authorized to create P0 governance/specification artifacts and where, under the repository privacy decision;
4. grant no implementation/import/dependency/PR/settings authority unless separately explicit;
5. require a fresh live identity/permission/ref check immediately before any later GitHub mutation.

Until that action, the reports are planning evidence. They do not begin P0 mutation, S1 implementation, PR disposition, repository containment or source acquisition.

---

## 40. Final Verdict and State

```text
MASTER_PLAN_V2_2_READY_FOR_FOUNDER_RATIFICATION
```

The architecture is reconciled and adversarially execution-readiness reviewed for founder ratification: direct V1.5 evidence is integrated, Stage-2 and bounded pre-ratification corrections are applied, source-acquisition and benchmark overclaims are removed, the roadmap remains ten primary slices plus non-primary S3-D, and the remaining founder action is the six-package ratification with two scoped blockers. It is not implementation authorization.

```text
V1_5_DIRECTLY_INSPECTED
YES

STAGE1_PRESERVED_UNCHANGED
YES

STAGE2_RECONCILED
YES

SPEC_KIT_BUILD_METHOD
REQUIRED

PONYTAIL_BUILD_METHOD
REQUIRED_FULL

CUBIC_BUILD_REVIEW
REQUIRED_WHEN_EGRESS_POLICY_PERMITS

PRIMARY_SLICES_COUNT
10

S3_D
NON_PRIMARY_ASSURANCE_SEED_GATE

CURRENT_SCOPED_BLOCKERS_COUNT
2

B-GOV-001
OPEN

B-WIN-001
OPEN

IMPLEMENTATION_AUTHORIZATION
NONE

REPOSITORY_MUTATION
NONE
```
